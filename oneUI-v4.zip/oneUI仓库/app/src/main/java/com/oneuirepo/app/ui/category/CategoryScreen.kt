package com.oneuirepo.app.ui.category

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.data.local.entity.RepositoryEntity
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape

internal data class Cat(val name: String, val emoji: String, val color: Color)

internal val categories = listOf(
    Cat("One UI 9", "9️⃣", Color(0xFF67A842)),
    Cat("One UI 8.5", "🔷", Color(0xFF808080)),
    Cat("One UI 8.0", "🟦", Color(0xFF4CA865)),
    Cat("SystemUI", "📱", Color(0xFF84A4C4)),
    Cat("RRO", "🎨", Color(0xFF5BB0DC)),
    Cat("主题", "🖌️", Color(0xFFD9737F)),
    Cat("字体", "🔤", Color(0xFFE0A24F)),
    Cat("模块", "🧩", Color(0xFF67A842)),
    Cat("LSPosed", "🪝", Color(0xFF5E7BC4)),
    Cat("Shizuku", "🛠️", Color(0xFF808080)),
    Cat("Root", "🔑", Color(0xFFD9737F)),
    Cat("KernelSU", "🧬", Color(0xFF9C8B5E)),
    Cat("Magisk", "🎭", Color(0xFF4CA865)),
    Cat("DeX", "🖥️", Color(0xFF84A4C4)),
    Cat("折叠屏", "📖", Color(0xFFB07CC6)),
    Cat("Watch", "⌚", Color(0xFFE08B5A)),
    Cat("CVE", "🛡️", Color(0xFFC0504D))
)

@Composable
fun CategoryScreen(db: AppDatabase, selected: String?, onSelect: (String?) -> Unit, onOpen: (Long) -> Unit) {
    if (selected == null) {
        CategoryList(db, onSelect)
    } else {
        BackHandler { onSelect(null) }
        CategoryDetail(db, selected, { onSelect(null) }, onOpen)
    }
}

@Composable
private fun CategoryList(db: AppDatabase, onSelect: (String?) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("项目分类", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        itemsIndexed(categories, key = { _, c -> c.name }) { _, cat ->
            CollectionCard(cat, db) { onSelect(cat.name) }
        }
    }
}

private fun fmt(n: Long): String = if (n >= 10000) String.format("%.1f万", n / 10000.0) else n.toString()

@Composable
private fun CollectionCard(cat: Cat, db: AppDatabase, onClick: () -> Unit) {
    val repos by db.categoryDao().observeRepos(cat.name).collectAsState(initial = emptyList())
    val stars = repos.fold(0L) { a, r -> a + r.stars }
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = cardShape(26.dp),
        border = cardBorder(),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            Modifier.fillMaxWidth().height(150.dp)
                .background(Brush.linearGradient(listOf(cat.color, cat.color.copy(alpha = 0.78f))))
                .padding(20.dp)
        ) {
            Column(Modifier.align(Alignment.TopStart), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("${cat.emoji} ${cat.name}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                Text(
                    if (cat.name == "CVE") "漏洞列表 · ${repos.size} 个相关项目" else "${repos.size} 个项目 · ⭐ ${fmt(stars)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.88f)
                )
            }
            Text(
                "点击查看 ›",
                modifier = Modifier.align(Alignment.BottomStart),
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White
            )
            AvatarStack(repos, Modifier.align(Alignment.BottomEnd))
        }
    }
}

@Composable
private fun AvatarStack(repos: List<RepositoryEntity>, modifier: Modifier) {
    val shown = repos.take(4)
    val extra = repos.size - shown.size
    val count = shown.size + (if (extra > 0) 1 else 0)
    if (count == 0) return
    val step = 26
    Box(modifier.width((step * (count - 1) + 36).dp).height(36.dp)) {
        shown.forEachIndexed { i, r ->
            Box(
                Modifier.offset(x = (i * step).dp).size(36.dp).clip(CircleShape)
                    .background(Color.White).border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                val a = r.avatarUrl
                if (a != null) {
                    AsyncImage(model = a, contentDescription = null, modifier = Modifier.fillMaxSize().clip(CircleShape))
                } else {
                    Text(r.name.take(1).uppercase(), color = Color.Black, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        if (extra > 0) {
            Box(
                Modifier.offset(x = (shown.size * step).dp).size(36.dp).clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.28f)).border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("+$extra", color = Color.White, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
