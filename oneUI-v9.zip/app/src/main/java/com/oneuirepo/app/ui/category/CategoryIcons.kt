package com.oneuirepo.app.ui.category

import androidx.compose.material.icons.materialIcon
import androidx.compose.material.icons.materialPath
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * 轻量本地矢量图标，不依赖 material-icons-extended，避免 Debug 构建 OOM。
 * 每个图标按分类语义设计。
 */
internal object CategoryIcons {

    val Number9: ImageVector by lazy {
        materialIcon(name = "Number9") {
            materialPath {
                // 简洁数字 9 轮廓
                moveTo(12f, 2f)
                curveToRelative(-2.2f, 0f, -4f, 1.8f, -4f, 4f)
                verticalLineToRelative(2f)
                curveToRelative(0f, 2.2f, 1.8f, 4f, 4f, 4f)
                reflectiveCurveToRelative(4f, -1.8f, 4f, -4f)
                verticalLineTo(6f)
                curveToRelative(0f, -2.2f, -1.8f, -4f, -4f, -4f)
                close()
                moveTo(12f, 10f)
                curveToRelative(-1.1f, 0f, -2f, -0.9f, -2f, -2f)
                verticalLineTo(6f)
                curveToRelative(0f, -1.1f, 0.9f, -2f, 2f, -2f)
                reflectiveCurveToRelative(2f, 0.9f, 2f, 2f)
                verticalLineToRelative(2f)
                curveToRelative(0f, 1.1f, -0.9f, 2f, -2f, 2f)
                close()
                moveTo(14f, 14f)
                horizontalLineToRelative(-2f)
                verticalLineToRelative(6f)
                horizontalLineToRelative(2f)
                close()
            }
        }
    }

    val Hexagon: ImageVector by lazy {
        materialIcon(name = "Hexagon") {
            materialPath {
                moveTo(12f, 2f)
                lineTo(20f, 7f)
                verticalLineToRelative(10f)
                lineTo(12f, 22f)
                lineTo(4f, 17f)
                verticalLineTo(7f)
                close()
                moveTo(12f, 4.5f)
                lineTo(6.5f, 8f)
                verticalLineToRelative(8f)
                lineTo(12f, 19.5f)
                lineTo(17.5f, 16f)
                verticalLineTo(8f)
                close()
            }
        }
    }

    val Square: ImageVector by lazy {
        materialIcon(name = "Square") {
            materialPath {
                moveTo(5f, 5f)
                horizontalLineToRelative(14f)
                verticalLineToRelative(14f)
                horizontalLineTo(5f)
                close()
                moveTo(7f, 7f)
                verticalLineToRelative(10f)
                horizontalLineToRelative(10f)
                verticalLineTo(7f)
                close()
            }
        }
    }

    val Phone: ImageVector by lazy {
        materialIcon(name = "Phone") {
            materialPath {
                moveTo(7f, 2f)
                horizontalLineToRelative(10f)
                curveToRelative(1.1f, 0f, 2f, 0.9f, 2f, 2f)
                verticalLineToRelative(16f)
                curveToRelative(0f, 1.1f, -0.9f, 2f, -2f, 2f)
                horizontalLineTo(7f)
                curveToRelative(-1.1f, 0f, -2f, -0.9f, -2f, -2f)
                verticalLineTo(4f)
                curveToRelative(0f, -1.1f, 0.9f, -2f, 2f, -2f)
                close()
                moveTo(7f, 4f)
                verticalLineToRelative(16f)
                horizontalLineToRelative(10f)
                verticalLineTo(4f)
                close()
                moveTo(10f, 17f)
                horizontalLineToRelative(4f)
                verticalLineToRelative(1.5f)
                horizontalLineToRelative(-4f)
                close()
            }
        }
    }

    val Palette: ImageVector by lazy {
        materialIcon(name = "Palette") {
            materialPath {
                moveTo(12f, 3f)
                curveToRelative(-4.97f, 0f, -9f, 4.03f, -9f, 9f)
                reflectiveCurveToRelative(4.03f, 9f, 9f, 9f)
                curveToRelative(0.83f, 0f, 1.5f, -0.67f, 1.5f, -1.5f)
                curveToRelative(0f, -0.39f, -0.15f, -0.74f, -0.39f, -1.01f)
                curveToRelative(-0.23f, -0.26f, -0.38f, -0.61f, -0.38f, -0.99f)
                curveToRelative(0f, -0.83f, 0.67f, -1.5f, 1.5f, -1.5f)
                horizontalLineTo(16f)
                curveToRelative(2.76f, 0f, 5f, -2.24f, 5f, -5f)
                curveToRelative(0f, -4.42f, -4.03f, -8f, -9f, -8f)
                close()
                moveTo(6.5f, 12f)
                curveToRelative(-0.83f, 0f, -1.5f, -0.67f, -1.5f, -1.5f)
                reflectiveCurveTo(5.67f, 9f, 6.5f, 9f)
                reflectiveCurveTo(8f, 9.67f, 8f, 10.5f)
                reflectiveCurveTo(7.33f, 12f, 6.5f, 12f)
                close()
                moveTo(9.5f, 8f)
                curveToRelative(-0.83f, 0f, -1.5f, -0.67f, -1.5f, -1.5f)
                reflectiveCurveTo(8.67f, 5f, 9.5f, 5f)
                reflectiveCurveTo(11f, 5.67f, 11f, 6.5f)
                reflectiveCurveTo(10.33f, 8f, 9.5f, 8f)
                close()
                moveTo(14.5f, 8f)
                curveToRelative(-0.83f, 0f, -1.5f, -0.67f, -1.5f, -1.5f)
                reflectiveCurveTo(13.67f, 5f, 14.5f, 5f)
                reflectiveCurveTo(16f, 5.67f, 16f, 6.5f)
                reflectiveCurveTo(15.33f, 8f, 14.5f, 8f)
                close()
                moveTo(17.5f, 12f)
                curveToRelative(-0.83f, 0f, -1.5f, -0.67f, -1.5f, -1.5f)
                reflectiveCurveTo(16.67f, 9f, 17.5f, 9f)
                reflectiveCurveTo(19f, 9.67f, 19f, 10.5f)
                reflectiveCurveTo(18.33f, 12f, 17.5f, 12f)
                close()
            }
        }
    }

    val Brush: ImageVector by lazy {
        materialIcon(name = "Brush") {
            materialPath {
                moveTo(7f, 14f)
                curveToRelative(-1.66f, 0f, -3f, 1.34f, -3f, 3f)
                curveToRelative(0f, 1.31f, -1.16f, 2f, -2f, 2f)
                curveToRelative(0.92f, 1.22f, 2.49f, 2f, 4f, 2f)
                curveToRelative(2.21f, 0f, 4f, -1.79f, 4f, -4f)
                curveToRelative(0f, -1.66f, -1.34f, -3f, -3f, -3f)
                close()
                moveTo(20.71f, 4.63f)
                lineToRelative(-1.34f, -1.34f)
                curveToRelative(-0.39f, -0.39f, -1.02f, -0.39f, -1.41f, 0f)
                lineTo(9f, 12.25f)
                lineTo(11.75f, 15f)
                lineToRelative(8.96f, -8.96f)
                curveToRelative(0.39f, -0.39f, 0.39f, -1.02f, 0f, -1.41f)
                close()
            }
        }
    }

    val TextFields: ImageVector by lazy {
        materialIcon(name = "TextFields") {
            materialPath {
                moveTo(2.5f, 5.5f)
                verticalLineTo(9f)
                horizontalLineToRelative(2f)
                verticalLineTo(7.5f)
                horizontalLineToRelative(4.5f)
                verticalLineToRelative(9f)
                horizontalLineTo(7.5f)
                verticalLineToRelative(2f)
                horizontalLineToRelative(7f)
                verticalLineToRelative(-2f)
                horizontalLineToRelative(-1.5f)
                verticalLineToRelative(-9f)
                horizontalLineTo(17f)
                verticalLineTo(9f)
                horizontalLineToRelative(2f)
                verticalLineTo(5.5f)
                close()
                moveTo(20f, 11f)
                horizontalLineToRelative(-6f)
                verticalLineToRelative(1.5f)
                horizontalLineToRelative(2.25f)
                verticalLineToRelative(5.5f)
                horizontalLineTo(18f)
                verticalLineToRelative(-5.5f)
                horizontalLineToRelative(2f)
                close()
            }
        }
    }

    val Extension: ImageVector by lazy {
        materialIcon(name = "Extension") {
            materialPath {
                moveTo(10.5f, 4.5f)
                curveToRelative(0f, -0.83f, 0.67f, -1.5f, 1.5f, -1.5f)
                reflectiveCurveToRelative(1.5f, 0.67f, 1.5f, 1.5f)
                verticalLineTo(6f)
                horizontalLineToRelative(2f)
                curveToRelative(1.1f, 0f, 2f, 0.9f, 2f, 2f)
                verticalLineToRelative(2f)
                horizontalLineToRelative(1.5f)
                curveToRelative(0.83f, 0f, 1.5f, 0.67f, 1.5f, 1.5f)
                reflectiveCurveToRelative(-0.67f, 1.5f, -1.5f, 1.5f)
                horizontalLineTo(17f)
                verticalLineToRelative(2f)
                curveToRelative(0f, 1.1f, -0.9f, 2f, -2f, 2f)
                horizontalLineToRelative(-2f)
                verticalLineToRelative(1.5f)
                curveToRelative(0f, 0.83f, -0.67f, 1.5f, -1.5f, 1.5f)
                reflectiveCurveToRelative(-1.5f, -0.67f, -1.5f, -1.5f)
                verticalLineTo(17f)
                horizontalLineToRelative(-2f)
                curveToRelative(-1.1f, 0f, -2f, -0.9f, -2f, -2f)
                verticalLineToRelative(-2f)
                horizontalLineTo(5.5f)
                curveToRelative(-0.83f, 0f, -1.5f, -0.67f, -1.5f, -1.5f)
                reflectiveCurveTo(4.67f, 10f, 5.5f, 10f)
                horizontalLineTo(7f)
                verticalLineTo(8f)
                curveToRelative(0f, -1.1f, 0.9f, -2f, 2f, -2f)
                horizontalLineToRelative(1.5f)
                close()
            }
        }
    }

    val Hook: ImageVector by lazy {
        materialIcon(name = "Hook") {
            materialPath {
                moveTo(16f, 4f)
                curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f)
                verticalLineToRelative(6.5f)
                curveToRelative(0f, 1.93f, -1.57f, 3.5f, -3.5f, 3.5f)
                reflectiveCurveTo(7f, 14.43f, 7f, 12.5f)
                verticalLineTo(11f)
                horizontalLineToRelative(2f)
                verticalLineToRelative(1.5f)
                curveToRelative(0f, 0.83f, 0.67f, 1.5f, 1.5f, 1.5f)
                reflectiveCurveToRelative(1.5f, -0.67f, 1.5f, -1.5f)
                verticalLineTo(6f)
                curveToRelative(0f, -2.21f, 1.79f, -4f, 4f, -4f)
                reflectiveCurveToRelative(4f, 1.79f, 4f, 4f)
                verticalLineToRelative(2f)
                horizontalLineToRelative(-2f)
                verticalLineTo(6f)
                curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f)
                close()
                moveTo(5f, 18f)
                horizontalLineToRelative(2f)
                verticalLineToRelative(2f)
                horizontalLineTo(5f)
                close()
                moveTo(9f, 16f)
                horizontalLineToRelative(2f)
                verticalLineToRelative(4f)
                horizontalLineTo(9f)
                close()
            }
        }
    }

    val Tools: ImageVector by lazy {
        materialIcon(name = "Tools") {
            materialPath {
                moveTo(22.7f, 19f)
                lineToRelative(-9.1f, -9.1f)
                curveToRelative(0.9f, -2.3f, 0.4f, -5f, -1.5f, -6.9f)
                curveToRelative(-2f, -2f, -5f, -2.4f, -7.4f, -1.3f)
                lineTo(9f, 6f)
                lineTo(6f, 9f)
                lineTo(1.6f, 4.7f)
                curveTo(0.4f, 7.1f, 0.9f, 10.1f, 2.9f, 12.1f)
                curveToRelative(1.9f, 1.9f, 4.6f, 2.4f, 6.9f, 1.5f)
                lineToRelative(9.1f, 9.1f)
                curveToRelative(0.4f, 0.4f, 1f, 0.4f, 1.4f, 0f)
                lineToRelative(2.3f, -2.3f)
                curveToRelative(0.5f, -0.4f, 0.5f, -1.1f, 0.1f, -1.4f)
                close()
            }
        }
    }

    val Key: ImageVector by lazy {
        materialIcon(name = "Key") {
            materialPath {
                moveTo(12.65f, 10f)
                curveTo(11.83f, 7.67f, 9.61f, 6f, 7f, 6f)
                curveToRelative(-3.31f, 0f, -6f, 2.69f, -6f, 6f)
                reflectiveCurveToRelative(2.69f, 6f, 6f, 6f)
                curveToRelative(2.61f, 0f, 4.83f, -1.67f, 5.65f, -4f)
                horizontalLineTo(17f)
                verticalLineToRelative(4f)
                horizontalLineToRelative(4f)
                verticalLineToRelative(-4f)
                horizontalLineToRelative(2f)
                verticalLineToRelative(-4f)
                horizontalLineTo(12.65f)
                close()
                moveTo(7f, 14f)
                curveToRelative(-1.1f, 0f, -2f, -0.9f, -2f, -2f)
                reflectiveCurveToRelative(0.9f, -2f, 2f, -2f)
                reflectiveCurveToRelative(2f, 0.9f, 2f, 2f)
                reflectiveCurveToRelative(-0.9f, 2f, -2f, 2f)
                close()
            }
        }
    }

    val Chip: ImageVector by lazy {
        materialIcon(name = "Chip") {
            materialPath {
                moveTo(6f, 4f)
                horizontalLineToRelative(12f)
                curveToRelative(1.1f, 0f, 2f, 0.9f, 2f, 2f)
                verticalLineToRelative(12f)
                curveToRelative(0f, 1.1f, -0.9f, 2f, -2f, 2f)
                horizontalLineTo(6f)
                curveToRelative(-1.1f, 0f, -2f, -0.9f, -2f, -2f)
                verticalLineTo(6f)
                curveToRelative(0f, -1.1f, 0.9f, -2f, 2f, -2f)
                close()
                moveTo(6f, 6f)
                verticalLineToRelative(12f)
                horizontalLineToRelative(12f)
                verticalLineTo(6f)
                close()
                moveTo(8f, 8f)
                horizontalLineToRelative(2f)
                verticalLineToRelative(2f)
                horizontalLineTo(8f)
                close()
                moveTo(12f, 8f)
                horizontalLineToRelative(2f)
                verticalLineToRelative(2f)
                horizontalLineToRelative(-2f)
                close()
                moveTo(8f, 12f)
                horizontalLineToRelative(2f)
                verticalLineToRelative(2f)
                horizontalLineTo(8f)
                close()
                moveTo(12f, 12f)
                horizontalLineToRelative(2f)
                verticalLineToRelative(2f)
                horizontalLineToRelative(-2f)
                close()
                moveTo(16f, 8f)
                horizontalLineToRelative(2f)
                verticalLineToRelative(8f)
                horizontalLineToRelative(-2f)
                close()
            }
        }
    }

    val Shield: ImageVector by lazy {
        materialIcon(name = "Shield") {
            materialPath {
                moveTo(12f, 1f)
                lineTo(3f, 5f)
                verticalLineToRelative(6f)
                curveToRelative(0f, 5.55f, 3.84f, 10.74f, 9f, 12f)
                curveToRelative(5.16f, -1.26f, 9f, -6.45f, 9f, -12f)
                verticalLineTo(5f)
                lineToRelative(-9f, -4f)
                close()
                moveTo(12f, 3.18f)
                lineToRelative(7f, 3.12f)
                verticalLineTo(11f)
                curveToRelative(0f, 4.52f, -2.98f, 8.69f, -7f, 9.93f)
                curveToRelative(-4.02f, -1.24f, -7f, -5.41f, -7f, -9.93f)
                verticalLineTo(6.3f)
                lineToRelative(7f, -3.12f)
                close()
            }
        }
    }

    val Desktop: ImageVector by lazy {
        materialIcon(name = "Desktop") {
            materialPath {
                moveTo(21f, 2f)
                horizontalLineTo(3f)
                curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f)
                verticalLineToRelative(12f)
                curveToRelative(0f, 1.1f, 0.9f, 2f, 2f, 2f)
                horizontalLineToRelative(7f)
                verticalLineToRelative(2f)
                horizontalLineTo(8f)
                verticalLineToRelative(2f)
                horizontalLineToRelative(8f)
                verticalLineToRelative(-2f)
                horizontalLineToRelative(-2f)
                verticalLineToRelative(-2f)
                horizontalLineToRelative(7f)
                curveToRelative(1.1f, 0f, 2f, -0.9f, 2f, -2f)
                verticalLineTo(4f)
                curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f)
                close()
                moveTo(21f, 16f)
                horizontalLineTo(3f)
                verticalLineTo(4f)
                horizontalLineToRelative(18f)
                verticalLineToRelative(12f)
                close()
            }
        }
    }

    val Tablet: ImageVector by lazy {
        materialIcon(name = "Tablet") {
            materialPath {
                moveTo(4f, 6f)
                horizontalLineToRelative(7f)
                verticalLineToRelative(12f)
                horizontalLineTo(4f)
                close()
                moveTo(13f, 6f)
                horizontalLineToRelative(7f)
                verticalLineToRelative(12f)
                horizontalLineToRelative(-7f)
                close()
                moveTo(2f, 4f)
                verticalLineToRelative(16f)
                curveToRelative(0f, 1.1f, 0.9f, 2f, 2f, 2f)
                horizontalLineToRelative(7f)
                verticalLineToRelative(-2f)
                horizontalLineTo(4f)
                verticalLineTo(6f)
                horizontalLineToRelative(7f)
                verticalLineTo(4f)
                horizontalLineTo(4f)
                curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f)
                close()
                moveTo(20f, 4f)
                horizontalLineToRelative(-7f)
                verticalLineToRelative(2f)
                horizontalLineToRelative(7f)
                verticalLineToRelative(12f)
                horizontalLineToRelative(-7f)
                verticalLineToRelative(2f)
                horizontalLineToRelative(7f)
                curveToRelative(1.1f, 0f, 2f, -0.9f, 2f, -2f)
                verticalLineTo(6f)
                curveToRelative(0f, -1.1f, -0.9f, -2f, -2f, -2f)
                close()
            }
        }
    }

    val Watch: ImageVector by lazy {
        materialIcon(name = "Watch") {
            materialPath {
                moveTo(12f, 6f)
                curveToRelative(-3.31f, 0f, -6f, 2.69f, -6f, 6f)
                reflectiveCurveToRelative(2.69f, 6f, 6f, 6f)
                reflectiveCurveToRelative(6f, -2.69f, 6f, -6f)
                reflectiveCurveToRelative(-2.69f, -6f, -6f, -6f)
                close()
                moveTo(12f, 16f)
                curveToRelative(-2.21f, 0f, -4f, -1.79f, -4f, -4f)
                reflectiveCurveToRelative(1.79f, -4f, 4f, -4f)
                reflectiveCurveToRelative(4f, 1.79f, 4f, 4f)
                reflectiveCurveToRelative(-1.79f, 4f, -4f, 4f)
                close()
                moveTo(10f, 2f)
                horizontalLineToRelative(4f)
                verticalLineToRelative(3f)
                horizontalLineToRelative(-4f)
                close()
                moveTo(10f, 19f)
                horizontalLineToRelative(4f)
                verticalLineToRelative(3f)
                horizontalLineToRelative(-4f)
                close()
            }
        }
    }

    val Label: ImageVector by lazy {
        materialIcon(name = "Label") {
            materialPath {
                moveTo(17.63f, 5.84f)
                curveTo(17.27f, 5.33f, 16.67f, 5f, 16f, 5f)
                horizontalLineTo(5f)
                curveToRelative(-1.1f, 0f, -2f, 0.9f, -2f, 2f)
                verticalLineToRelative(10f)
                curveToRelative(0f, 1.1f, 0.9f, 2f, 2f, 2f)
                horizontalLineToRelative(11f)
                curveToRelative(0.67f, 0f, 1.27f, -0.33f, 1.63f, -0.84f)
                lineTo(22f, 12f)
                lineToRelative(-4.37f, -6.16f)
                close()
                moveTo(16f, 17f)
                horizontalLineTo(5f)
                verticalLineTo(7f)
                horizontalLineToRelative(11f)
                lineToRelative(3.55f, 5f)
                lineTo(16f, 17f)
                close()
            }
        }
    }

    val Security: ImageVector by lazy {
        materialIcon(name = "Security") {
            materialPath {
                moveTo(12f, 1f)
                lineTo(3f, 5f)
                verticalLineToRelative(6f)
                curveToRelative(0f, 5.55f, 3.84f, 10.74f, 9f, 12f)
                curveToRelative(5.16f, -1.26f, 9f, -6.45f, 9f, -12f)
                verticalLineTo(5f)
                lineToRelative(-9f, -4f)
                close()
                moveTo(12f, 11.99f)
                horizontalLineToRelative(7f)
                curveToRelative(-0.53f, 4.12f, -3.28f, 7.79f, -7f, 8.94f)
                verticalLineTo(12f)
                horizontalLineTo(5f)
                verticalLineTo(6.3f)
                lineToRelative(7f, -3.11f)
                verticalLineToRelative(8.8f)
                close()
            }
        }
    }
}
