package com.oneuirepo.app.ui.settings

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.oneuirepo.app.auth.AuthState
import com.oneuirepo.app.auth.DeviceCode
import com.oneuirepo.app.auth.GitHubAuth
import com.oneuirepo.app.auth.PollResult
import com.oneuirepo.app.data.remote.GitHubClient
import com.oneuirepo.app.settings.AppSettings
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class Profile(val login: String, val name: String, val avatar: String)

sealed interface LoginUi {
    data object Idle : LoginUi
    data object Starting : LoginUi
    data class WaitingDevice(val userCode: String, val verifyUri: String) : LoginUi
    data object WaitingBackend : LoginUi
    data class Error(val message: String) : LoginUi
}

class GitHubAccountViewModel(private val app: Context) : ViewModel() {
    private val settings = AppSettings(app)
    private val _profile = MutableStateFlow(loadProfile())
    val profile: StateFlow<Profile?> = _profile.asStateFlow()
    private val _ui = MutableStateFlow<LoginUi>(LoginUi.Idle)
    val ui: StateFlow<LoginUi> = _ui.asStateFlow()
    private var job: Job? = null

    init {
        // token 存在但资料为空（例如刚从后端回调回来）时补拉一次
        if (AuthState.token != null && _profile.value == null) viewModelScope.launch { loadUser() }
        viewModelScope.launch { AuthState.callback.collect { uri -> if (uri != null) { handleCallback(uri); AuthState.callback.value = null } } }
    }

    val clientId get() = settings.clientId
    val backendUrl get() = settings.backendUrl
    fun saveConfig(clientId: String, backend: String) { settings.clientId = clientId; settings.backendUrl = backend }

    private fun loadProfile(): Profile? =
        if (AuthState.token != null && settings.profileLogin.isNotBlank())
            Profile(settings.profileLogin, settings.profileName, settings.profileAvatar) else null

    // ---------- Device Flow（推荐，无需后端） ----------
    fun startDeviceLogin(clientId: String) {
        val id = clientId.trim()
        if (id.isEmpty()) { _ui.value = LoginUi.Error("请先填写 Client ID（在高级设置里）"); return }
        settings.clientId = id
        job?.cancel()
        _ui.value = LoginUi.Starting
        job = viewModelScope.launch {
            val dc: DeviceCode = try { GitHubAuth.requestDeviceCode(id) } catch (t: Throwable) {
                _ui.value = LoginUi.Error(t.message ?: "无法连接 GitHub，请检查网络"); return@launch
            }
            _ui.value = LoginUi.WaitingDevice(dc.userCode, dc.verificationUri)
            var interval = dc.interval
            val deadline = System.currentTimeMillis() + dc.expiresIn * 1000L
            while (System.currentTimeMillis() < deadline) {
                delay(interval * 1000L)
                when (val r = GitHubAuth.pollOnce(id, dc.deviceCode)) {
                    is PollResult.Token -> { finishLogin(r.value); return@launch }
                    PollResult.Pending -> Unit
                    PollResult.SlowDown -> interval += 5
                    PollResult.Expired -> { _ui.value = LoginUi.Error("验证码已过期，请重新登录"); return@launch }
                    PollResult.Denied -> { _ui.value = LoginUi.Error("你在 GitHub 上拒绝了授权"); return@launch }
                    is PollResult.Failed -> { _ui.value = LoginUi.Error(r.message); return@launch }
                }
            }
            _ui.value = LoginUi.Error("等待超时，请重新登录")
        }
    }

    // ---------- 自有 OAuth 后端 ----------
    /** 校验后端地址，返回要在浏览器打开的 URL；不合法返回 null 并设置错误。 */
    fun prepareBackendLogin(raw: String): Uri? {
        val u = raw.trim().trimEnd('/')
        val parsed = runCatching { Uri.parse(u) }.getOrNull()
        val host = parsed?.host.orEmpty()
        val err = when {
            u.isEmpty() -> "请填写 OAuth 后端 HTTPS 地址"
            parsed?.scheme != "https" || host.isEmpty() -> "后端地址必须以 https:// 开头"
            host == "example.com" || host.endsWith(".example.com") -> "这是示例地址，请换成你自己部署的后端"
            else -> null
        }
        if (err != null) { _ui.value = LoginUi.Error(err); return null }
        settings.backendUrl = u
        val state = UUID.randomUUID().toString()
        settings.oauthState = state
        _ui.value = LoginUi.WaitingBackend
        return Uri.parse("$u/login").buildUpon()
            .appendQueryParameter("redirect_uri", "com.oneuirepo.app://auth")
            .appendQueryParameter("state", state)
            .build()
    }

    private fun handleCallback(uri: Uri) {
        val err = uri.getQueryParameter("error")
        val token = uri.getQueryParameter("access_token") ?: uri.getQueryParameter("token")
        val state = uri.getQueryParameter("state")
        when {
            err != null -> _ui.value = LoginUi.Error("授权失败：$err")
            settings.oauthState.isEmpty() || state != settings.oauthState ->
                _ui.value = LoginUi.Error("回调校验失败（state 不匹配），请重新登录")
            token.isNullOrBlank() -> _ui.value = LoginUi.Error("后端没有返回令牌，请检查后端的回调参数")
            else -> viewModelScope.launch { settings.oauthState = ""; finishLogin(token) }
        }
    }

    // ---------- 公共 ----------
    private suspend fun finishLogin(token: String) {
        AuthState.setToken(app, token)
        if (!loadUser()) return
        _ui.value = LoginUi.Idle
    }

    private suspend fun loadUser(): Boolean = try {
        val u = GitHubClient.api.getUser()
        settings.profileLogin = u.login; settings.profileName = u.name.orEmpty(); settings.profileAvatar = u.avatarUrl.orEmpty()
        _profile.value = Profile(u.login, u.name.orEmpty(), u.avatarUrl.orEmpty())
        true
    } catch (t: Throwable) {
        val unauthorized = (t as? retrofit2.HttpException)?.code() == 401
        if (unauthorized) { logout(); _ui.value = LoginUi.Error("令牌无效或已被撤销，请重新登录") }
        else _ui.value = LoginUi.Error("已拿到令牌，但读取账号信息失败：${t.message ?: "网络错误"}")
        false
    }

    fun cancel() { job?.cancel(); settings.oauthState = ""; _ui.value = LoginUi.Idle }

    fun dismissError() { if (_ui.value is LoginUi.Error) _ui.value = LoginUi.Idle }

    fun logout() {
        job?.cancel()
        AuthState.setToken(app, null)
        settings.profileLogin = ""; settings.profileName = ""; settings.profileAvatar = ""
        _profile.value = null
        _ui.value = LoginUi.Idle
    }
}

class GitHubAccountVMFactory(private val app: Context) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = GitHubAccountViewModel(app.applicationContext) as T
}
