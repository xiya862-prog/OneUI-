package com.oneuirepo.app.data.local.dao

import androidx.room.*
import com.oneuirepo.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertView(x: ViewHistoryEntity)

    @Query("SELECT r.* FROM repositories r INNER JOIN view_history v ON r.id=v.repositoryId ORDER BY v.viewedAt DESC LIMIT 100")
    fun observeRecent(): Flow<List<RepositoryEntity>>

    @Query("DELETE FROM view_history")
    suspend fun clearViews()

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun markDiscovered(x: DiscoveredEntity)

    @Query("DELETE FROM discovered WHERE repositoryId=:id")
    suspend fun unmarkDiscovered(id: Long)
}
