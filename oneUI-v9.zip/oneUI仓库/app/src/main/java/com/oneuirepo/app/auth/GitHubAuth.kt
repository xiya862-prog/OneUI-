package com.oneuirepo.app.auth

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class DeviceCode(
    val deviceCode: String,
    val userCode: String,
    val verificationUri: String,
    val expiresIn: Int,
    val interval: Int
)

sealed interface PollResult {
    data class Token(val value: String) : PollResult
    data object Pending : PollResult
    data object SlowDown : PollResult
    data object Expired : PollResult
    data object Denied : PollResult
    data class Failed(val message: String) : PollResult
}

/**
 * GitHub Device Flow：只需要 Client ID，不需要 Client Secret，也不需要自己的后端。
 * 前提：GitHub OAuth App 里勾选了 "Enable Device Flow"。
 */
object GitHubAuth {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private const val DEVICE_URL = "https://github.com/login/device/code"
    private const val TOKEN_URL = "https://github.com/login/oauth/access_token"

    private fun post(url: String, form: FormBody): JSONObject {
        val req = Request.Builder().url(url).header("Accept", "application/json").post(form).build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            return runCatching { JSONObject(body) }.getOrElse { throw IllegalStateException("GitHub 返回了无法识别的内容（HTTP ${r.code}）") }
        }
    }

    suspend fun requestDeviceCode(clientId: String): DeviceCode = withContext(Dispatchers.IO) {
        val j = post(
            DEVICE_URL,
            FormBody.Builder().add("client_id", clientId).add("scope", "read:user").build()
        )
        if (j.has("error")) {
            val msg = when (j.getString("error")) {
                "device_flow_disabled" -> "这个 OAuth App 没有开启 Device Flow：请到 GitHub → Developer settings → OAuth Apps，勾选 Enable Device Flow 后点 Update application"
                "incorrect_client_credentials", "unauthorized_client" -> "Client ID 不正确，请检查后重试"
                else -> j.optString("error_description").ifBlank { j.getString("error") }
            }
            throw IllegalStateException(msg)
        }
        DeviceCode(
            deviceCode = j.getString("device_code"),
            userCode = j.getString("user_code"),
            verificationUri = j.getString("verification_uri"),
            expiresIn = j.optInt("expires_in", 900),
            interval = j.optInt("interval", 5).coerceAtLeast(5)
        )
    }

    suspend fun pollOnce(clientId: String, deviceCode: String): PollResult = withContext(Dispatchers.IO) {
        try {
            val j = post(
                TOKEN_URL,
                FormBody.Builder()
                    .add("client_id", clientId)
                    .add("device_code", deviceCode)
                    .add("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
                    .build()
            )
            when {
                j.has("access_token") -> PollResult.Token(j.getString("access_token"))
                else -> when (val e = j.optString("error")) {
                    "authorization_pending" -> PollResult.Pending
                    "slow_down" -> PollResult.SlowDown
                    "expired_token" -> PollResult.Expired
                    "access_denied" -> PollResult.Denied
                    else -> PollResult.Failed(j.optString("error_description").ifBlank { e.ifBlank { "未知错误" } })
                }
            }
        } catch (t: Throwable) {
            // 网络抖动不应该中断授权流程，当作"还在等待"
            PollResult.Pending
        }
    }
}
