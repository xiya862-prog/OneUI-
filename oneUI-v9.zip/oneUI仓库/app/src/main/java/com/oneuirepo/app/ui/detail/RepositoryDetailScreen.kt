package com.oneuirepo.app.ui.detail

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import com.oneuirepo.app.ui.category.NewCategoryDialog
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.*
import kotlinx.coroutines.launch
import androidx.lifecycle.viewmodel.compose.viewModel
import coil3.compose.AsyncImage
import com.oneuirepo.app.data.local.dao.*
import com.oneuirepo.app.data.local.entity.*
import com.oneuirepo.app.download.AppDownloadManager

class RepositoryDetailViewModel(private val db:com.oneuirepo.app.data.local.AppDatabase, private val id:Long):ViewModel(){
    val repository=db.repositoryDao().observeById(id)
    val releases=db.releaseDao().observeReleases(id)
    val assets=db.releaseDao().observeAssets(id)
    val favorite=db.favoriteDao().observeIsFavorite(id)
    fun toggleFavorite(current:Boolean)=viewModelScope.launch{if(current)db.favoriteDao().remove(id) else db.favoriteDao().add(FavoriteEntity(id,System.currentTimeMillis()))}
}
class RepositoryDetailFactory(private val db:com.oneuirepo.app.data.local.AppDatabase,private val id:Long):ViewModelProvider.Factory{
    @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T=RepositoryDetailViewModel(db,id) as T
}


private val PRE_REGEX = Regex("(?<![a-z])(alpha|beta|rc\\d*|pre|nightly|dev|snapshot|canary|preview)(?![a-z])", RegexOption.IGNORE_CASE)

private fun isPre(r: ReleaseEntity): Boolean = PRE_REGEX.containsMatchIn(r.tagName + " " + r.name.orEmpty())

private fun fmtCount(n: Long): String = when {
    n >= 1_000_000 -> String.format("%.1fM", n / 1_000_000.0).replace(".0M", "M")
    n >= 1_000 -> String.format("%.1fk", n / 1_000.0).replace(".0k", "k")
    else -> n.toString()
}

private fun fmtSize(b: Long): String = String.format("%.1f MB", b / 1048576.0)

private fun archOf(a: ReleaseAssetEntity): String {
    val n = a.name.lowercase()
    return when {
        n.contains("arm64") || n.contains("aarch64") -> "aarch64"
        n.contains("armeabi") || n.contains("armv7") || n.contains("arm32") -> "armv7"
        n.contains("x86_64") || n.contains("amd64") || n.contains("x64") -> "x86_64"
        n.contains("x86") -> "x86"
        n.contains("universal") -> "universal"
        else -> a.fileType.uppercase()
    }
}

private fun bestAsset(list: List<ReleaseAssetEntity>): ReleaseAssetEntity? {
    if (list.isEmpty()) return null
    val apks = list.filter { it.name.lowercase().endsWith(".apk") }
    if (apks.isEmpty()) return list.first()
    val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull().orEmpty()
    val keys = when (abi) {
        "arm64-v8a" -> listOf("arm64", "aarch64")
        "armeabi-v7a" -> listOf("armeabi", "armv7", "arm32")
        "x86_64" -> listOf("x86_64", "x64", "amd64")
        else -> listOf("x86")
    }
    return apks.firstOrNull { a -> keys.any { a.name.lowercase().contains(it) } }
        ?: apks.firstOrNull { it.name.lowercase().contains("universal") }
        ?: apks.first()
}

private fun platforms(assets: List<ReleaseAssetEntity>): List<Pair<String, String>> {
    val n = assets.map { it.name.lowercase() }
    val out = mutableListOf<Pair<String, String>>()
    if (n.any { it.endsWith(".apk") || it.endsWith(".aab") }) out.add("🤖" to "Android")
    if (n.any { it.endsWith(".exe") || it.endsWith(".msi") || it.contains("windows") || it.contains("win64") || it.contains("win32") || it.contains("-win") }) out.add("🪟" to "Windows")
    if (n.any { it.endsWith(".dmg") || it.endsWith(".pkg") || it.contains("macos") || it.contains("osx") || it.contains("darwin") || it.contains("-mac") }) out.add("🍎" to "macOS")
    if (n.any { it.endsWith(".deb") || it.endsWith(".rpm") || it.endsWith(".appimage") || it.contains("linux") }) out.add("🐧" to "Linux")
    return out
}

private fun relTime(iso: String?): String {
    if (iso == null) return "未知"
    return try {
        val t = java.time.Instant.parse(iso).toEpochMilli()
        val m = (System.currentTimeMillis() - t) / 60000
        when {
            m < 1 -> "刚刚"
            m < 60 -> "${m} 分钟前"
            m < 60 * 24 -> "${m / 60} 小时前"
            m < 60 * 24 * 30 -> "${m / (60 * 24)} 天前"
            else -> iso.take(10)
        }
    } catch (e: Exception) {
        iso.take(10)
    }
}

@Composable
private fun Stripes(modifier: Modifier) {
    val line = MaterialTheme.colorScheme.primary.copy(alpha = 0.40f)
    val bg = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
    Canvas(modifier.clipToBounds().background(bg)) {
        val step = 44.dp.toPx()
        val w = size.width
        val h = size.height
        var x = -h
        while (x < w) {
            drawLine(line, Offset(x, h), Offset(x + h, 0f), strokeWidth = step / 2)
            x += step
        }
    }
}

@Composable
private fun <T> Selector(label: String, value: String, options: List<Pair<T, String>>, modifier: Modifier, onSelect: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val border = cardBorder() ?: BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 8.dp, bottom = 4.dp))
        Box {
            Card(
                onClick = { open = true },
                modifier = Modifier.fillMaxWidth(),
                shape = cardShape(20.dp),
                border = border,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(value, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("⌄")
                }
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { (k, t) ->
                    DropdownMenuItem(text = { Text(t, maxLines = 2) }, onClick = { open = false; onSelect(k) })
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier) {
    val border = cardBorder() ?: BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    Card(
        modifier = modifier,
        shape = cardShape(20.dp),
        border = border,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, Modifier.width(84.dp), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun RepositoryDetailScreen(id: Long, db: com.oneuirepo.app.data.local.AppDatabase, onBack: () -> Unit) {
    androidx.activity.compose.BackHandler(onBack = onBack)
    val vm: RepositoryDetailViewModel = viewModel(key = "detail_$id", factory = RepositoryDetailFactory(db, id))
    val r by vm.repository.collectAsState(initial = null)
    val releases by vm.releases.collectAsState(initial = emptyList())
    val assets by vm.assets.collectAsState(initial = emptyList())
    val favorite by vm.favorite.collectAsState(initial = false)
    val cats by db.categoryDao().observeForRepo(id).collectAsState(initial = emptyList<String>())
    val context = LocalContext.current
    val downloader = remember { AppDownloadManager(context) }
    var channel by remember { mutableStateOf(0) }
    var relId by remember { mutableStateOf<Long?>(null) }
    var assetId by remember { mutableStateOf<Long?>(null) }
    var topMenu by remember { mutableStateOf(false) }
    var installMenu by remember { mutableStateOf(false) }
    var readmeFull by remember { mutableStateOf(false) }
    var showNew by remember { mutableStateOf(false) }
    val custom by db.categoryDao().observeCustom().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    val border = cardBorder() ?: BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    val surface = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)

    fun openUrl(u: String) {
        context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(u)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    fun share(u: String) {
        val i = android.content.Intent(android.content.Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(android.content.Intent.EXTRA_TEXT, u) }
        context.startActivity(android.content.Intent.createChooser(i, null).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    fun toast(t: String) { android.widget.Toast.makeText(context, t, android.widget.Toast.LENGTH_SHORT).show() }

    val filtered = releases.filter { when (channel) { 0 -> !isPre(it); 1 -> isPre(it); else -> true } }
    val rel = filtered.firstOrNull { it.id == relId } ?: filtered.firstOrNull()
    val relAssets = if (rel == null) emptyList() else assets.filter { it.releaseId == rel.id }.sortedByDescending { it.name.lowercase().endsWith(".apk") }
    val asset = relAssets.firstOrNull { it.id == assetId } ?: bestAsset(relAssets)

    Scaffold { p ->
        Column(Modifier.fillMaxSize().padding(p)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                FilledTonalIconButton(onClick = onBack) { Text("←", style = MaterialTheme.typography.titleLarge) }
                Spacer(Modifier.weight(1f))
                Box {
                    IconButton(onClick = { topMenu = true }) { Text("⋯", style = MaterialTheme.typography.titleLarge) }
                    DropdownMenu(expanded = topMenu, onDismissRequest = { topMenu = false }) {
                        DropdownMenuItem(text = { Text(if (favorite) "取消收藏" else "收藏") }, onClick = { topMenu = false; vm.toggleFavorite(favorite) })
                        DropdownMenuItem(text = { Text("分享项目链接") }, onClick = { topMenu = false; r?.let { share(it.htmlUrl) } })
                    }
                }
            }
            val x = r
            if (x == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // ---- 头部卡片
                    item {
                        Card(Modifier.fillMaxWidth(), shape = cardShape(28.dp), border = border, colors = surface) {
                            Column {
                                Box(Modifier.fillMaxWidth().height(150.dp)) {
                                    Stripes(Modifier.fillMaxWidth().height(100.dp))
                                    Row(Modifier.align(Alignment.BottomStart).padding(horizontal = 16.dp), verticalAlignment = Alignment.Bottom) {
                                        Box(
                                            Modifier.size(96.dp).clip(cardShape(22.dp)).background(Color.White)
                                                .border(3.dp, MaterialTheme.colorScheme.primary, cardShape(22.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            val icon = x.iconUrl ?: x.avatarUrl
                                            if (icon != null) AsyncImage(model = icon, contentDescription = null, modifier = Modifier.fillMaxSize().padding(6.dp))
                                            else Text(x.name.take(1).uppercase(), style = MaterialTheme.typography.headlineMedium, color = Color.Black)
                                        }
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.padding(bottom = 4.dp)) {
                                            Text(x.owner, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(x.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("🕘 最近更新 ${relTime(x.updatedAt)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    val desc = x.description.orEmpty()
                                    if (desc.isNotBlank()) Text(desc, style = MaterialTheme.typography.bodyLarge)
                                    val pf = platforms(assets)
                                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        pf.forEach { (emoji, name) ->
                                            Surface(shape = cardShape(14.dp), color = MaterialTheme.colorScheme.surface, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
                                                Text("$emoji  $name", Modifier.padding(horizontal = 14.dp, vertical = 10.dp), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                            }
                                        }
                                        val lang = x.language.orEmpty()
                                        if (lang.isNotBlank()) {
                                            Surface(shape = cardShape(14.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                                                Text("💻  $lang", Modifier.padding(horizontal = 14.dp, vertical = 10.dp), style = MaterialTheme.typography.bodyMedium)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    // ---- 版本通道
                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            listOf("稳定版", "预发布", "全部").forEachIndexed { i, t ->
                                FilterChip(selected = channel == i, onClick = { channel = i; relId = null; assetId = null }, label = { Text(t) })
                            }
                        }
                    }
                    // ---- 安装区
                    if (rel == null || asset == null) {
                        item {
                            Card(Modifier.fillMaxWidth(), shape = cardShape(22.dp), border = border, colors = surface) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(if (releases.isEmpty()) "该项目暂无 Release 安装包" else "这个通道下没有可下载的文件", style = MaterialTheme.typography.titleMedium)
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        OutlinedButton(onClick = { openUrl(x.htmlUrl) }) { Text("在 GitHub 查看") }
                                        Button(onClick = {
                                            downloader.enqueue("https://github.com/${x.owner}/${x.name}/archive/HEAD.zip", "${x.name}-source.zip")
                                            toast("已开始下载源码 ZIP")
                                        }) { Text("⬇ 下载源码 ZIP") }
                                    }
                                }
                            }
                        }
                    } else {
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Selector("资源", asset.name, relAssets.map { it.id to it.name }, Modifier.weight(1.7f)) { assetId = it }
                                Selector("版本", rel.tagName, filtered.map { it.id to it.tagName }, Modifier.weight(1f)) { relId = it; assetId = null }
                            }
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = {
                                        downloader.enqueue(asset.downloadUrl, asset.name)
                                        toast("已开始下载，完成后在通知栏点击安装")
                                    },
                                    modifier = Modifier.weight(1f).height(74.dp),
                                    shape = cardShape(26.dp)
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(if (rel.id == filtered.firstOrNull()?.id) "⬇ 安装最新版本" else "⬇ 下载此版本", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            archOf(asset) + " · " + fmtSize(asset.size) + (if (!asset.digest.isNullOrBlank()) "  ✔" else ""),
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    }
                                }
                                Box {
                                    Button(onClick = { installMenu = true }, modifier = Modifier.height(74.dp).width(64.dp), shape = cardShape(26.dp), contentPadding = PaddingValues(0.dp)) {
                                        Text("⌄", style = MaterialTheme.typography.titleLarge)
                                    }
                                    DropdownMenu(expanded = installMenu, onDismissRequest = { installMenu = false }) {
                                        DropdownMenuItem(text = { Text("在 GitHub 查看此版本") }, onClick = { installMenu = false; openUrl(rel.htmlUrl) })
                                        DropdownMenuItem(text = { Text("复制下载链接") }, onClick = {
                                            installMenu = false
                                            val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                            cm.setPrimaryClip(android.content.ClipData.newPlainText("url", asset.downloadUrl))
                                            toast("已复制")
                                        })
                                        DropdownMenuItem(text = { Text("分享下载链接") }, onClick = { installMenu = false; share(asset.downloadUrl) })
                                        DropdownMenuItem(text = { Text("下载源码 ZIP") }, onClick = {
                                            installMenu = false
                                            downloader.enqueue("https://github.com/${x.owner}/${x.name}/archive/HEAD.zip", "${x.name}-source.zip")
                                            toast("已开始下载源码 ZIP")
                                        })
                                    }
                                }
                            }
                        }
                    }
                    // ---- 统计
                    item { Text("统计", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Stat("分支", fmtCount(x.forks.toLong()), Modifier.weight(1f))
                                Stat("星标", fmtCount(x.stars.toLong()), Modifier.weight(1f))
                                Stat("关注者", fmtCount(x.watchers.toLong()), Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Stat("下载量", fmtCount(assets.fold(0L) { a, s -> a + s.downloadCount }), Modifier.weight(1f))
                                Stat("许可证", x.license?.takeIf { it.isNotBlank() } ?: "未知", Modifier.weight(1.3f))
                            }
                        }
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            FilledTonalButton(onClick = { openUrl(x.htmlUrl + "/issues") }, modifier = Modifier.weight(1f).height(52.dp)) { Text("Issues", fontWeight = FontWeight.Bold) }
                            FilledTonalButton(onClick = { openUrl(x.htmlUrl + "/security") }, modifier = Modifier.weight(1f).height(52.dp)) { Text("安全", fontWeight = FontWeight.Bold) }
                        }
                    }
                    // ---- 关于
                    item {
                        Card(Modifier.fillMaxWidth(), shape = cardShape(22.dp), border = border, colors = surface) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("关于", style = MaterialTheme.typography.titleLarge)
                                InfoRow("分类", cats.map { it.removePrefix("c:") }.joinToString("、").ifBlank { "未分类" })
                                InfoRow("标签", x.topics.replace("\n", "、").ifBlank { "无" })
                                InfoRow("One UI", x.oneUiVersions.ifBlank { "未识别" })
                                InfoRow("Android", x.androidVersions.ifBlank { "未识别" })
                                InfoRow("设备", x.deviceCompatibility.ifBlank { "未识别" })
                                InfoRow("环境要求", x.requirements.ifBlank { "未识别" })
                                Text("我的分类", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 6.dp))
                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    custom.forEach { c ->
                                        val on = cats.contains(c.id)
                                        FilterChip(
                                            selected = on,
                                            onClick = {
                                                scope.launch {
                                                    if (on) db.categoryDao().removeLink(id, c.id)
                                                    else db.categoryDao().addLink(RepositoryCategoryCrossRef(id, c.id))
                                                }
                                            },
                                            label = { Text(c.name) }
                                        )
                                    }
                                    AssistChip(onClick = { showNew = true }, label = { Text("＋ 新建分类") })
                                }
                                if (showNew) {
                                    NewCategoryDialog(
                                        existing = custom.map { it.name }.toSet(),
                                        onDismiss = { showNew = false }
                                    ) { name ->
                                        scope.launch {
                                            db.categoryDao().upsertAll(listOf(CategoryEntity("c:" + name, name)))
                                            db.categoryDao().addLink(RepositoryCategoryCrossRef(id, "c:" + name))
                                        }
                                        showNew = false
                                    }
                                }
                            }
                        }
                    }
                    // ---- README
                    item {
                        Card(Modifier.fillMaxWidth(), shape = cardShape(22.dp), border = border, colors = surface) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("README", style = MaterialTheme.typography.titleLarge)
                                val full = x.readme.orEmpty().ifBlank { "暂无 README" }
                                Text(if (readmeFull) full.take(12000) else full.take(900), style = MaterialTheme.typography.bodyMedium)
                                if (full.length > 900) TextButton(onClick = { readmeFull = !readmeFull }) { Text(if (readmeFull) "收起" else "展开全部") }
                            }
                        }
                    }
                    // ---- 历史版本
                    item { Text("历史版本", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
                    items(releases, key = { it.id }) { item ->
                        Card(Modifier.fillMaxWidth(), shape = cardShape(22.dp), border = border, colors = surface) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(item.tagName, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                    if (isPre(item)) com.oneuirepo.app.ui.common.Pill("预发布")
                                }
                                Text(relTime(item.publishedAt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                val notes = item.body.orEmpty()
                                if (notes.isNotBlank()) Text(notes.take(600), maxLines = 6, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                                assets.filter { it.releaseId == item.id }.forEach { a ->
                                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                        Text("${a.name} · ${fmtSize(a.size)}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 2)
                                        TextButton(onClick = { downloader.enqueue(a.downloadUrl, a.name); toast("已开始下载") }) { Text("下载") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
