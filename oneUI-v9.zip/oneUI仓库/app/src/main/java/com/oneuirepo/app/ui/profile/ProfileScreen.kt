package com.oneuirepo.app.ui.profile

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil3.compose.AsyncImage
import com.oneuirepo.app.data.remote.GitHubUserDto
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.settings.AppSettings
import com.oneuirepo.app.ui.common.*
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape

private enum class Section(val title: String) {
    HOME("个人资料"), STARRED("星标"), FAVORITES("收藏"), RECENT("最近查看"), FOLLOWERS("关注者"), FOLLOWING("正在关注")
}

@Composable
fun ProfileScreen(c: AppContainer, onBack: () -> Unit, onOpen: (Long) -> Unit) {
    val vm: ProfileViewModel = viewModel(factory = ProfileVMFactory(c))
    var section by rememberSaveable { mutableStateOf(Section.HOME) }
    BackHandler { if (section == Section.HOME) onBack() else section = Section.HOME }
    val opening by vm.opening.collectAsState()
    val favFlow = remember { c.db.repositoryDao().observeFavorites() }
    val recentFlow = remember { c.db.historyDao().observeRecent() }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (section == Section.HOME) onBack() else section = Section.HOME }) {
                AppIcon(IconKind.BACK, MaterialTheme.colorScheme.onBackground, 22.dp)
            }
            Text(section.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (opening) LinearProgressIndicator(Modifier.fillMaxWidth())
        when (section) {
            Section.HOME -> HomeSection(vm, c, onGo = { section = it })
            Section.STARRED -> StarredSection(vm, onOpen)
            Section.FAVORITES -> RepoListSection(favFlow, "还没有收藏，在项目详情里点收藏", onOpen)
            Section.RECENT -> RepoListSection(recentFlow, "还没有查看记录", onOpen)
            Section.FOLLOWERS -> UsersSection(vm.followers, "还没有人关注你")
            Section.FOLLOWING -> UsersSection(vm.following, "你还没有关注任何人")
        }
    }
}

@Composable
private fun HomeSection(vm: ProfileViewModel, c: AppContainer, onGo: (Section) -> Unit) {
    val context = LocalContext.current
    val settings = remember { AppSettings(context) }
    val me by vm.me.collectAsState()
    val err by vm.meError.collectAsState()
    val login = me?.login ?: settings.profileLogin
    val name = me?.name?.takeIf { it.isNotBlank() } ?: settings.profileName.ifBlank { login }
    val avatar = me?.avatarUrl ?: settings.profileAvatar

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (!vm.loggedIn) {
            item { EmptyHint("还没有登录，请先到「设置」里使用 GitHub 登录") }
        } else {
            item {
                Card(Modifier.fillMaxWidth(), shape = cardShape(28.dp), border = cardBorder(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Box(Modifier.size(84.dp).clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surfaceVariant)) {
                                if (avatar.isNotEmpty()) AsyncImage(avatar, null, Modifier.fillMaxSize())
                            }
                            Column(Modifier.weight(1f)) {
                                Text(name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("@$login", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                        Row(Modifier.fillMaxWidth()) {
                            Stat("仓库", me?.publicRepos, Modifier.weight(1f)) {
                                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/$login?tab=repositories")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                            }
                            Stat("关注者", me?.followers, Modifier.weight(1f)) { vm.followers.loadMore(); onGo(Section.FOLLOWERS) }
                            Stat("正在关注", me?.following, Modifier.weight(1f)) { vm.following.loadMore(); onGo(Section.FOLLOWING) }
                        }
                        err?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
        item { Text("我的内容", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, top = 4.dp)) }
        item {
            Card(Modifier.fillMaxWidth(), shape = cardShape(26.dp), border = cardBorder(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))) {
                Column {
                    LibraryRow(IconKind.STAR, "星标", "你在 GitHub 上加了星标的仓库") { vm.starred.loadMore(); onGo(Section.STARRED) }
                    HorizontalDivider(Modifier.padding(start = 76.dp, end = 16.dp))
                    LibraryRow(IconKind.HEART, "收藏", "本地保存的收藏仓库") { onGo(Section.FAVORITES) }
                    HorizontalDivider(Modifier.padding(start = 76.dp, end = 16.dp))
                    LibraryRow(IconKind.CLOCK, "最近查看", "你访问过的仓库") { onGo(Section.RECENT) }
                }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: Int?, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value?.toString() ?: "–", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LibraryRow(icon: IconKind, title: String, desc: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface), contentAlignment = Alignment.Center) {
            AppIcon(icon, MaterialTheme.colorScheme.onSurfaceVariant, 22.dp)
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        AppIcon(IconKind.CHEVRON, MaterialTheme.colorScheme.onSurfaceVariant, 20.dp)
    }
}

@Composable
private fun StarredSection(vm: ProfileViewModel, onOpen: (Long) -> Unit) {
    val items by vm.starred.items.collectAsState()
    val loading by vm.starred.loading.collectAsState()
    val more by vm.starred.more.collectAsState()
    val error by vm.starred.error.collectAsState()
    val syncMsg by vm.syncMsg.collectAsState()
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!vm.loggedIn) { item { EmptyHint("请先到「设置」里登录 GitHub") }; return@LazyColumn }
        item {
            Card(Modifier.fillMaxWidth(), shape = cardShape(20.dp), border = cardBorder(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("把已加载的星标仓库一键同步到本地收藏，之后离线也能看。", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    FilledTonalButton(onClick = vm::syncStarredToFavorites, enabled = items.isNotEmpty()) { Text("同步星标到收藏（${items.size}）") }
                    syncMsg?.let { Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary) }
                }
            }
        }
        if (items.isEmpty() && !loading && error == null) item { EmptyHint("你还没有在 GitHub 上加星标") }
        items(items, key = { it.id }) { d -> RemoteRepoCard(d) { vm.open(d, onOpen) } }
        item {
            when {
                error != null -> Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error!!, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = { vm.starred.loadMore() }) { Text("重试") }
                }
                loading -> Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                more && items.isNotEmpty() -> {
                    LaunchedEffect(items.size) { vm.starred.loadMore() }
                }
            }
        }
    }
}

@Composable
private fun RepoListSection(flow: kotlinx.coroutines.flow.Flow<List<com.oneuirepo.app.data.local.entity.RepositoryEntity>>, empty: String, onOpen: (Long) -> Unit) {
    val list by flow.collectAsState(initial = emptyList())
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (list.isEmpty()) item { EmptyHint(empty) }
        items(list, key = { it.id }) { r -> RepoCard(r) { onOpen(r.id) } }
    }
}

@Composable
private fun UsersSection(p: Paged<GitHubUserDto>, empty: String) {
    val context = LocalContext.current
    val items by p.items.collectAsState()
    val loading by p.loading.collectAsState()
    val more by p.more.collectAsState()
    val error by p.error.collectAsState()
    LaunchedEffect(Unit) { if (items.isEmpty()) p.loadMore() }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (items.isEmpty() && !loading && error == null) item { EmptyHint(empty) }
        items(items, key = { it.login }) { u ->
            Card(
                onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u.htmlUrl ?: "https://github.com/${u.login}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } },
                Modifier.fillMaxWidth(), shape = cardShape(20.dp), border = cardBorder(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer)) {
                        u.avatarUrl?.let { AsyncImage(it, null, Modifier.fillMaxSize()) }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(u.login, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("github.com/${u.login}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    AppIcon(IconKind.CHEVRON, MaterialTheme.colorScheme.onSurfaceVariant, 18.dp)
                }
            }
        }
        item {
            when {
                error != null -> Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error!!, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = { p.loadMore() }) { Text("重试") }
                }
                loading -> Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                more && items.isNotEmpty() -> LaunchedEffect(items.size) { p.loadMore() }
            }
        }
    }
}
