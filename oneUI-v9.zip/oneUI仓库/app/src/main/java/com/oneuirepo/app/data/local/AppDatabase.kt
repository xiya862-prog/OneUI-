package com.oneuirepo.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.oneuirepo.app.data.local.dao.*
import com.oneuirepo.app.data.local.entity.*

@Database(entities=[RepositoryEntity::class,CategoryEntity::class,RepositoryCategoryCrossRef::class,ReleaseEntity::class,ReleaseAssetEntity::class,FavoriteEntity::class,SyncStateEntity::class,com.oneuirepo.app.cve.CveEntity::class,com.oneuirepo.app.cve.RepositoryCveCrossRef::class,ViewHistoryEntity::class,DiscoveredEntity::class],version=4,exportSchema=true)
abstract class AppDatabase:RoomDatabase(){
    abstract fun repositoryDao():RepositoryDao
    abstract fun categoryDao():CategoryDao
    abstract fun releaseDao():ReleaseDao
    abstract fun favoriteDao():FavoriteDao
    abstract fun syncStateDao():SyncStateDao
    abstract fun cveDao(): CveDao
    abstract fun historyDao(): HistoryDao
}
