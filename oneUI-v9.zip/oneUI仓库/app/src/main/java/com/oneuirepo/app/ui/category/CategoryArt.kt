package com.oneuirepo.app.ui.category

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import kotlin.math.cos
import kotlin.math.sin

private val W = Color.White

/**
 * 每个分类按它"真正是什么"画一幅线面结合的矢量插画（手机 SystemUI、RRO 图层、字体 Aa、
 * 模块拼图、Shizuku 水滴、终端 #、芯片、折叠屏、手表、盾牌……），不使用 emoji。
 * [ink] 是卡片的深色，用来画镂空 / 细节。
 */
@Composable
fun CategoryArt(name: String, ink: Color, modifier: Modifier = Modifier, size: Dp = 96.dp) {
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) { art(name, ink) }
        when {
            name.startsWith("One UI") -> {
                val v = name.removePrefix("One UI").trim()
                Text(v, color = ink.copy(alpha = 0.92f), fontWeight = FontWeight.Black, fontSize = (size.value * if (v.length > 1) 0.30f else 0.46f).sp)
            }
            name == "字体" -> Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.46f).sp)) { append("A") }
                    withStyle(SpanStyle(fontFamily = FontFamily.SansSerif, fontWeight = FontWeight.Black, fontSize = (size.value * 0.34f).sp)) { append("a") }
                },
                color = W
            )
        }
    }
}

/** 带参考图的分类（KernelSU / Magisk / LSPosed）返回图片资源，其余为 null。 */
internal fun categoryImage(name: String): Int? = when (name) {
    "KernelSU" -> com.oneuirepo.app.R.drawable.cat_kernelsu
    "Magisk" -> com.oneuirepo.app.R.drawable.cat_magisk
    "LSPosed" -> com.oneuirepo.app.R.drawable.cat_lsposed
    else -> null
}

/** 小号徽标：有图用图，没图用毛玻璃底 + 矢量插画。 */
@Composable
internal fun CategoryBadge(cat: Cat, size: Dp) {
    val img = categoryImage(cat.name)
    val shape = RoundedCornerShape(size / 3.4f)
    if (img != null) {
        Image(painterResource(img), null, Modifier.size(size).clip(shape), contentScale = ContentScale.Crop)
    } else {
        Box(Modifier.size(size).clip(shape).background(W.copy(alpha = 0.22f)), contentAlignment = Alignment.Center) {
            CategoryArt(cat.name, cat.color.deep(), size = size * 0.8f)
        }
    }
}

internal fun Color.deep(f: Float = 0.72f) = Color(red * f, green * f, blue * f, alpha)

// ---------------------------------------------------------------------------------------------

private fun DrawScope.art(name: String, ink: Color) {
    val u = size.minDimension / 100f
    fun o(x: Float, y: Float) = Offset(x * u, y * u)
    fun sz(w: Float, h: Float) = Size(w * u, h * u)
    fun rr(x: Float, y: Float, w: Float, h: Float, r: Float, a: Float = 1f, ink: Color? = null) =
        drawRoundRect(ink ?: W.copy(alpha = a), o(x, y), sz(w, h), CornerRadius(r * u))
    fun line(x1: Float, y1: Float, x2: Float, y2: Float, w: Float, c: Color = W) =
        drawLine(c, o(x1, y1), o(x2, y2), w * u, StrokeCap.Round)

    when {
        name.startsWith("One UI") -> {
            // 圆角方块 = One UI 的大圆角卡片，下方一条滑块
            rr(10f, 8f, 80f, 80f, 28f, 0.28f)
            rr(24f, 90f, 52f, 6f, 3f, 0.55f)
        }
        name == "SystemUI" -> {
            drawRoundRect(W, o(24f, 6f), sz(52f, 88f), CornerRadius(12f * u), style = Stroke(4.5f * u))
            drawCircle(W, 2.6f * u, o(34f, 17f))
            rr(60f, 14.5f, 9f, 5f, 2f, 0.9f)
            rr(31f, 28f, 17f, 14f, 6f, 0.95f); rr(52f, 28f, 17f, 14f, 6f, 0.55f)
            rr(31f, 46f, 17f, 14f, 6f, 0.55f); rr(52f, 46f, 17f, 14f, 6f, 0.95f)
            rr(31f, 68f, 38f, 6f, 3f, 0.4f); rr(31f, 68f, 24f, 6f, 3f, 0.95f)
        }
        name == "RRO" -> {
            // 三层叠加的菱形：运行时资源覆盖层
            fun layer(y: Float, a: Float) {
                val p = Path().apply { moveTo(50f * u, y * u); lineTo(90f * u, (y + 20f) * u); lineTo(50f * u, (y + 40f) * u); lineTo(10f * u, (y + 20f) * u); close() }
                drawPath(p, W.copy(alpha = a))
                drawPath(p, ink.copy(alpha = 0.25f), style = Stroke(1.6f * u, join = StrokeJoin.Round))
            }
            layer(52f, 0.35f); layer(34f, 0.62f); layer(16f, 1f)
        }
        name == "主题" -> {
            val body = Path().apply { addOval(Rect(o(8f, 14f), sz(84f, 76f))) }
            val hole = Path().apply { addOval(Rect(o(58f, 56f), sz(24f, 22f))) }
            drawPath(Path.combine(PathOperation.Difference, body, hole), W)
            val dots = listOf(Triple(28f, 40f, 0.95f), Triple(46f, 28f, 0.7f), Triple(66f, 30f, 0.5f), Triple(24f, 62f, 0.6f))
            dots.forEach { (x, y, a) -> drawCircle(ink.copy(alpha = a), 6.5f * u, o(x, y)) }
        }
        name == "字体" -> {
            // 排版基线 / 升线 / 降线
            line(8f, 22f, 92f, 22f, 1.6f, W.copy(alpha = 0.4f)); line(8f, 52f, 92f, 52f, 1.6f, W.copy(alpha = 0.4f))
            line(8f, 80f, 92f, 80f, 1.6f, W.copy(alpha = 0.4f))
        }
        name == "模块" -> {
            rr(54f, 8f, 36f, 36f, 10f, 0.4f)
            val body = Path().apply { addRoundRect(androidx.compose.ui.geometry.RoundRect(Rect(o(12f, 34f), sz(54f, 54f)), CornerRadius(8f * u))) }
            val top = Path().apply { addOval(Rect(o(28f, 20f), sz(22f, 22f))) }
            val right = Path().apply { addOval(Rect(o(56f, 49f), sz(22f, 22f))) }
            val left = Path().apply { addOval(Rect(o(1f, 49f), sz(22f, 22f))) }
            var p = Path.combine(PathOperation.Union, body, top)
            p = Path.combine(PathOperation.Union, p, right)
            p = Path.combine(PathOperation.Difference, p, left)
            drawPath(p, W)
        }
        name == "Shizuku" -> {
            val p = Path().apply {
                moveTo(50f * u, 6f * u)
                cubicTo(60f * u, 24f * u, 80f * u, 40f * u, 80f * u, 62f * u)
                arcTo(Rect(o(20f, 32f), sz(60f, 60f)), 0f, 180f, false)
                cubicTo(20f * u, 40f * u, 40f * u, 24f * u, 50f * u, 6f * u)
                close()
            }
            drawPath(p, W)
            drawArc(ink.copy(alpha = 0.35f), 100f, 55f, false, o(31f, 43f), sz(38f, 38f), style = Stroke(4.5f * u, cap = StrokeCap.Round))
            // 水波
            drawOval(W.copy(alpha = 0.45f), o(14f, 90f), sz(72f, 8f), style = Stroke(2f * u))
        }
        name == "Root" -> {
            rr(6f, 14f, 88f, 72f, 12f, 0.26f)
            drawCircle(W.copy(alpha = 0.9f), 2.6f * u, o(17f, 25f)); drawCircle(W.copy(alpha = 0.6f), 2.6f * u, o(26f, 25f)); drawCircle(W.copy(alpha = 0.35f), 2.6f * u, o(35f, 25f))
            // # 提示符 + 光标
            line(24f, 52f, 54f, 52f, 5f); line(22f, 67f, 52f, 67f, 5f)
            line(35f, 40f, 31f, 78f, 5f); line(48f, 40f, 44f, 78f, 5f)
            rr(62f, 48f, 12f, 28f, 3f, 0.95f)
        }
        name == "DeX" -> {
            drawRoundRect(W.copy(alpha = 0.26f), o(6f, 12f), sz(88f, 58f), CornerRadius(8f * u))
            drawRoundRect(W, o(6f, 12f), sz(88f, 58f), CornerRadius(8f * u), style = Stroke(4f * u))
            rr(14f, 22f, 34f, 24f, 4f, 0.95f); rr(52f, 22f, 34f, 14f, 4f, 0.6f)
            rr(12f, 58f, 76f, 6f, 3f, 0.55f)
            line(50f, 70f, 50f, 84f, 5f); line(32f, 86f, 68f, 86f, 5f)
            rr(70f, 46f, 22f, 40f, 6f, 1f); rr(74f, 52f, 14f, 24f, 3f, ink = ink.copy(alpha = 0.45f))
        }
        name == "折叠屏" -> {
            rr(8f, 16f, 41f, 68f, 12f, 1f)
            rr(51f, 16f, 41f, 68f, 12f, 0.55f)
            drawCircle(ink.copy(alpha = 0.5f), 2.4f * u, o(41f, 26f))
            line(60f, 30f, 82f, 30f, 3f, ink.copy(alpha = 0.3f)); line(60f, 40f, 78f, 40f, 3f, ink.copy(alpha = 0.3f))
        }
        name == "Watch" -> {
            rr(35f, 4f, 30f, 30f, 6f, 0.45f); rr(35f, 66f, 30f, 30f, 6f, 0.45f)
            rr(80f, 42f, 8f, 16f, 3f, 0.7f)
            drawCircle(W, 30f * u, o(50f, 50f))
            for (i in 0 until 12) {
                val a = Math.toRadians(i * 30.0 - 90)
                val r1 = if (i % 3 == 0) 22f else 24.5f
                drawLine(ink.copy(alpha = 0.55f), o(50f + 26f * cos(a).toFloat(), 50f + 26f * sin(a).toFloat()), o(50f + r1 * cos(a).toFloat(), 50f + r1 * sin(a).toFloat()), 1.8f * u, StrokeCap.Round)
            }
            line(50f, 50f, 50f, 33f, 4.5f, ink); line(50f, 50f, 63f, 57f, 4.5f, ink)
            drawCircle(ink, 3.4f * u, o(50f, 50f))
        }
        name == "CVE" -> {
            val p = Path().apply {
                moveTo(50f * u, 5f * u); lineTo(86f * u, 18f * u); lineTo(86f * u, 48f * u)
                cubicTo(86f * u, 70f * u, 68f * u, 85f * u, 50f * u, 95f * u)
                cubicTo(32f * u, 85f * u, 14f * u, 70f * u, 14f * u, 48f * u)
                lineTo(14f * u, 18f * u); close()
            }
            drawPath(p, W)
            line(50f, 28f, 50f, 54f, 8f, ink); drawCircle(ink, 5f * u, o(50f, 70f))
        }
        else -> { // 自定义分类：标签
            val p = Path().apply {
                moveTo(14f * u, 14f * u); lineTo(52f * u, 14f * u); lineTo(88f * u, 50f * u)
                lineTo(50f * u, 88f * u); lineTo(14f * u, 52f * u); close()
            }
            drawPath(p, W)
            drawCircle(ink.copy(alpha = 0.7f), 7f * u, o(32f, 32f))
        }
    }
}
