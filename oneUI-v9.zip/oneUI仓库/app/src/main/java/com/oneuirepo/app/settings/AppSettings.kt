package com.oneuirepo.app.settings

import android.content.Context

class AppSettings(context: Context) {
    private val p = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
    var autoSync: Boolean
        get() = p.getBoolean("autoSync", true)
        set(v) { p.edit().putBoolean("autoSync", v).apply() }
    var notifications: Boolean
        get() = p.getBoolean("notifications", true)
        set(v) { p.edit().putBoolean("notifications", v).apply() }
    var imageLoading: Boolean
        get() = p.getBoolean("imageLoading", true)
        set(v) { p.edit().putBoolean("imageLoading", v).apply() }
    var mangaStyle: Boolean
        get() = p.getBoolean("manga", false)
        set(v) { p.edit().putBoolean("manga", v).apply() }
    var themeMode: Int
        get() = p.getInt("themeMode", 0)
        set(v) { p.edit().putInt("themeMode", v).apply() }
    var clientId: String
        get() = p.getString("oauthClientId", "Ov23liJ7t7ZnfM3id19Q") ?: ""
        set(v) { p.edit().putString("oauthClientId", v.trim()).apply() }
    var backendUrl: String
        get() = p.getString("oauthBackend", "") ?: ""
        set(v) { p.edit().putString("oauthBackend", v.trim()).apply() }
    var oauthState: String
        get() = p.getString("oauthPendingState", "") ?: ""
        set(v) { p.edit().putString("oauthPendingState", v).apply() }
    var profileLogin: String
        get() = p.getString("profileLogin", "") ?: ""
        set(v) { p.edit().putString("profileLogin", v).apply() }
    var profileName: String
        get() = p.getString("profileName", "") ?: ""
        set(v) { p.edit().putString("profileName", v).apply() }
    var profileAvatar: String
        get() = p.getString("profileAvatar", "") ?: ""
        set(v) { p.edit().putString("profileAvatar", v).apply() }
}
