package com.oneuirepo.app.ui.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.oneuirepo.app.auth.AuthState
import com.oneuirepo.app.cve.CveScheduler
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.settings.AppSettings
import com.oneuirepo.app.settings.DataManager
import com.oneuirepo.app.sync.SyncScheduler
import com.oneuirepo.app.ui.theme.ThemeState
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(container: AppContainer, onOpenProfile: () -> Unit = {}) {
    val context = LocalContext.current
    val settings = remember { AppSettings(context) }
    val scope = rememberCoroutineScope()
    val account: GitHubAccountViewModel = viewModel(factory = GitHubAccountVMFactory(context))
    val profile by account.profile.collectAsState()
    var auto by remember { mutableStateOf(settings.autoSync) }
    var notify by remember { mutableStateOf(settings.notifications) }
    var images by remember { mutableStateOf(settings.imageLoading) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("设置", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))

        GroupTitle("账号")
        GitHubAccountCard(account, onOpenProfile)

        GroupTitle("同步与通知")
        GroupCard {
            SettingSwitch("自动同步", "后台定期检查项目", auto) { auto = it; settings.autoSync = it; if (it) SyncScheduler.schedule(context) else SyncScheduler.cancel(context) }
            RowDivider()
            SettingSwitch("通知", "新 Release 通知", notify) { notify = it; settings.notifications = it }
            RowDivider()
            SettingSwitch("图片加载", "加载 GitHub 头像和项目图片", images) { images = it; settings.imageLoading = it }
            RowDivider()
            SettingAction("立即同步项目", "手动检查所有项目的更新") { SyncScheduler.runNow(context) }
            RowDivider()
            SettingAction("立即同步 CVE", "刷新漏洞列表") { CveScheduler.runNow(context) }
        }

        GroupTitle("外观")
        GroupCard {
            SettingSwitch("Manga 漫画风", "粗描边、纸张质感的漫画面板风格", ThemeState.manga) { ThemeState.setManga(context, it) }
            RowDivider()
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("跟随系统", "日间", "夜间", "Nord").forEachIndexed { i, t ->
                    FilterChip(selected = ThemeState.mode == i, onClick = { ThemeState.setMode(context, i) }, label = { Text(t) })
                }
            }
        }

        GroupTitle("数据")
        GroupCard {
            SettingAction("导出数据", "把项目、分类和收藏导出为 JSON") { scope.launch { DataManager.share(context, DataManager.exportJson(container.db)) } }
        }

        GroupTitle("关于")
        GroupCard {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    if (profile != null || AuthState.token != null) "GitHub API：已登录，使用账号额度（5000 次/小时）"
                    else "GitHub API：匿名访问（60 次/小时），登录后可提升",
                    style = MaterialTheme.typography.bodySmall
                )
                Text("版本：1.0.0", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun GroupTitle(text: String) {
    Text(
        text, Modifier.padding(start = 6.dp, top = 10.dp),
        style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold
    )
}

@Composable
private fun GroupCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        Modifier.fillMaxWidth(), shape = cardShape(22.dp), border = cardBorder(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) { Column(content = content) }
}

@Composable
private fun RowDivider() = HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.surfaceVariant)

@Composable
private fun SettingSwitch(title: String, desc: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable { onChange(!value) }.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(value, onChange)
    }
}

@Composable
private fun SettingAction(title: String, desc: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("›", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
