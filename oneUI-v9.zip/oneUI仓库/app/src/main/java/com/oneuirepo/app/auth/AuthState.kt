package com.oneuirepo.app.auth

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.flow.MutableStateFlow
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** 全局登录状态：GitHubClient 的拦截器读取 [token] 给 api.github.com 请求加 Authorization。 */
object AuthState {
    @Volatile
    var token: String? = null
        private set

    /** 后端 OAuth 回调（com.oneuirepo.app://auth?...）从 MainActivity 投递到这里。 */
    val callback = MutableStateFlow<Uri?>(null)

    fun init(context: Context) {
        token = TokenStore.load(context)
    }

    fun setToken(context: Context, value: String?) {
        token = value
        TokenStore.save(context, value)
    }
}

/** 用 Android Keystore 的 AES-GCM 加密后再存 SharedPreferences，备份/还原到别的设备后会自动失效为"未登录"。 */
private object TokenStore {
    private const val ALIAS = "oneui_github_token_key"
    private const val PREFS = "auth_secure"
    private const val KEY = "token"

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun save(context: Context, token: String?) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (token == null) { p.edit().remove(KEY).apply(); return }
        runCatching {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, secretKey())
            val out = c.iv + c.doFinal(token.toByteArray())
            p.edit().putString(KEY, Base64.encodeToString(out, Base64.NO_WRAP)).apply()
        }
    }

    fun load(context: Context): String? = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return null
        val bytes = Base64.decode(raw, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, bytes, 0, 12))
        String(c.doFinal(bytes, 12, bytes.size - 12))
    }.getOrNull()
}
