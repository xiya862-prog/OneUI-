package com.oneuirepo.app.ui.category

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.data.local.entity.CategoryEntity
import com.oneuirepo.app.data.local.entity.RepositoryEntity
import kotlinx.coroutines.launch
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape

internal data class Cat(val name: String, val color: Color, val id: String = name)

internal val categories = listOf(
    Cat("One UI 9", Color(0xFF5B8DEF)),
    Cat("One UI 8.5", Color(0xFF6C7A89)),
    Cat("One UI 8.0", Color(0xFF3FA77A)),
    Cat("SystemUI", Color(0xFF6F8FB8)),
    Cat("RRO", Color(0xFF4FA3D1)),
    Cat("主题", Color(0xFFD9737F)),
    Cat("字体", Color(0xFFD99A45)),
    Cat("模块", Color(0xFF67A842)),
    Cat("LSPosed", Color(0xFFFFB02E)),
    Cat("Shizuku", Color(0xFF3AA6A0)),
    Cat("Root", Color(0xFF8E6BBF)),
    Cat("KernelSU", Color(0xFF3F51B5)),
    Cat("Magisk", Color(0xFFE8315B)),
    Cat("DeX", Color(0xFF4F7DB5)),
    Cat("折叠屏", Color(0xFFB07CC6)),
    Cat("Watch", Color(0xFFE08B5A)),
    Cat("CVE", Color(0xFFC0504D))
)

@Composable
fun CategoryScreen(db: AppDatabase, selected: String?, onSelect: (String?) -> Unit, onOpen: (Long) -> Unit) {
    if (selected == null) {
        CategoryList(db, onSelect)
    } else {
        BackHandler { onSelect(null) }
        CategoryDetail(db, selected, { onSelect(null) }, onOpen)
    }
}

@Composable
private fun CategoryList(db: AppDatabase, onSelect: (String?) -> Unit) {
    val custom by db.categoryDao().observeCustom().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var showNew by remember { mutableStateOf(false) }
    val customCats = custom.map { e -> Cat(e.name, categories[(e.id.hashCode() and 0x7fffffff) % categories.size].color, e.id) }
    val all = categories + customCats
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("项目分类", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("共 ${all.size} 个分类", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                FilledTonalButton(onClick = { showNew = true }) { Text("＋ 新建") }
            }
        }
        items(all, key = { it.id }) { cat ->
            CollectionCard(cat, db) { onSelect(cat.id) }
        }
    }
    if (showNew) {
        NewCategoryDialog(
            existing = (categories.map { it.name } + custom.map { it.name }).toSet(),
            onDismiss = { showNew = false }
        ) { name ->
            scope.launch { db.categoryDao().upsertAll(listOf(CategoryEntity("c:" + name, name))) }
            showNew = false
        }
    }
}

private fun fmt(n: Long): String = if (n >= 10000) String.format("%.1f万", n / 10000.0) else n.toString()

@Composable
private fun CollectionCard(cat: Cat, db: AppDatabase, onClick: () -> Unit) {
    val repos by db.categoryDao().observeRepos(cat.id).collectAsState(initial = emptyList())
    val stars = repos.fold(0L) { a, r -> a + r.stars }
    val img = categoryImage(cat.name)
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(164.dp),
        shape = cardShape(26.dp),
        border = cardBorder(),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(Modifier.fillMaxSize()) {
            if (img != null) {
                // 参考图作为整张卡片的封面
                Image(painterResource(img), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(cat.color.lighten(), cat.color.deep(0.82f)))))
                // 柔光
                Box(
                    Modifier.size(150.dp).offset(x = 70.dp, y = (-50).dp).clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.10f))
                )
                CategoryArt(cat.name, cat.color.deep(), Modifier.align(Alignment.TopEnd).padding(top = 12.dp, end = 12.dp), size = 84.dp)
            }
            // 底部压暗，保证文字清晰
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        0.45f to Color.Transparent,
                        1f to Color.Black.copy(alpha = if (img != null) 0.62f else 0.30f)
                    )
                )
            )
            AvatarStack(repos, Modifier.align(Alignment.TopStart).padding(12.dp))
            Column(Modifier.align(Alignment.BottomStart).padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(
                    cat.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                    color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CountChip(if (cat.name == "CVE") "${repos.size} 个相关" else "${repos.size} 个项目")
                    if (cat.name != "CVE" && stars > 0) {
                        Text("★", color = Color(0xFFFFD54F), style = MaterialTheme.typography.labelMedium)
                        Text(fmt(stars), style = MaterialTheme.typography.labelMedium, color = Color.White, maxLines = 1)
                    }
                }
            }
        }
    }
}

private fun Color.lighten(f: Float = 0.18f) = Color(red + (1 - red) * f, green + (1 - green) * f, blue + (1 - blue) * f, alpha)

@Composable
private fun CountChip(text: String) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.22f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = Color.White, maxLines = 1)
    }
}

@Composable
private fun AvatarStack(repos: List<RepositoryEntity>, modifier: Modifier) {
    val shown = repos.take(2)
    val extra = repos.size - shown.size
    val count = shown.size + (if (extra > 0) 1 else 0)
    if (count == 0) return
    val step = 15
    Box(modifier.width((step * (count - 1) + 24).dp).height(24.dp)) {
        shown.forEachIndexed { i, r ->
            Box(
                Modifier.offset(x = (i * step).dp).size(24.dp).clip(CircleShape)
                    .background(Color.White).border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                val a = r.avatarUrl
                if (a != null) {
                    AsyncImage(model = a, contentDescription = null, modifier = Modifier.fillMaxSize().clip(CircleShape))
                } else {
                    Text(r.name.take(1).uppercase(), color = Color.Black, style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        if (extra > 0) {
            Box(
                Modifier.offset(x = (shown.size * step).dp).size(24.dp).clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.28f)).border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("+$extra", color = Color.White, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}
