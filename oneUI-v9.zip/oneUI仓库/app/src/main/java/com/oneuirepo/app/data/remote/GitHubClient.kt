package com.oneuirepo.app.data.remote
import com.oneuirepo.app.auth.AuthState
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
object GitHubClient {
    private val http by lazy {
        OkHttpClient.Builder().addInterceptor { chain ->
            val t = AuthState.token
            val req = chain.request()
            // 只给 api.github.com 带令牌，避免泄露到其他域名
            if (t != null && req.url.host == "api.github.com" && req.header("Authorization") == null)
                chain.proceed(req.newBuilder().header("Authorization", "Bearer $t").build())
            else chain.proceed(req)
        }.build()
    }
    val api: GitHubApi by lazy {
        Retrofit.Builder().baseUrl("https://api.github.com/").client(http)
            .addConverterFactory(Json { ignoreUnknownKeys = true }.asConverterFactory("application/json".toMediaType()))
            .build().create(GitHubApi::class.java)
    }
}
