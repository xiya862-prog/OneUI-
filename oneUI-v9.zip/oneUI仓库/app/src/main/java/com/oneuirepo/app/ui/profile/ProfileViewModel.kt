package com.oneuirepo.app.ui.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.oneuirepo.app.auth.AuthState
import com.oneuirepo.app.data.local.entity.FavoriteEntity
import com.oneuirepo.app.data.remote.GitHubClient
import com.oneuirepo.app.data.remote.GitHubRepositoryDto
import com.oneuirepo.app.data.remote.GitHubUserDto
import com.oneuirepo.app.data.repository.AppContainer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

private const val PAGE = 50

private fun msg(e: Exception): String = when {
    e is retrofit2.HttpException && e.code() == 401 -> "登录已失效，请到设置里重新登录"
    e is retrofit2.HttpException && (e.code() == 403 || e.code() == 429) -> "GitHub 请求太频繁，请稍后再试"
    else -> "网络错误：" + (e.message ?: "未知")
}

/** 通用的分页列表：每页 50 条，不足一页即视为到底。 */
class Paged<T>(private val scope: CoroutineScope, private val fetch: suspend (Int) -> List<T>) {
    private val _items = MutableStateFlow<List<T>>(emptyList())
    val items: StateFlow<List<T>> = _items.asStateFlow()
    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()
    private val _more = MutableStateFlow(true)
    val more: StateFlow<Boolean> = _more.asStateFlow()
    private var page = 1

    fun loadMore() {
        if (_loading.value || !_more.value) return
        scope.launch {
            _loading.value = true; _error.value = null
            try {
                val r = fetch(page)
                _items.value = _items.value + r
                _more.value = r.size >= PAGE
                page++
            } catch (e: Exception) { _error.value = msg(e) } finally { _loading.value = false }
        }
    }

    fun reload() { _items.value = emptyList(); page = 1; _more.value = true; _error.value = null; loadMore() }
}

class ProfileViewModel(private val c: AppContainer) : ViewModel() {
    private val api = GitHubClient.api
    private val _me = MutableStateFlow<GitHubUserDto?>(null)
    val me: StateFlow<GitHubUserDto?> = _me.asStateFlow()
    private val _meError = MutableStateFlow<String?>(null)
    val meError: StateFlow<String?> = _meError.asStateFlow()

    val starred = Paged(viewModelScope) { api.getStarred(PAGE, it) }
    val following = Paged(viewModelScope) { api.getFollowing(PAGE, it) }
    val followers = Paged(viewModelScope) { api.getFollowers(PAGE, it) }

    private val _opening = MutableStateFlow(false)
    val opening: StateFlow<Boolean> = _opening.asStateFlow()
    private val _syncMsg = MutableStateFlow<String?>(null)
    val syncMsg: StateFlow<String?> = _syncMsg.asStateFlow()
    private var syncing = false

    val loggedIn get() = AuthState.token != null

    init { if (loggedIn) refreshMe() }

    fun refreshMe() {
        viewModelScope.launch {
            _meError.value = null
            try { _me.value = api.getUser() } catch (e: Exception) { _meError.value = msg(e) }
        }
    }

    fun open(dto: GitHubRepositoryDto, onDone: (Long) -> Unit) {
        if (_opening.value) return
        viewModelScope.launch {
            _opening.value = true
            try { onDone(c.repository.importRemote(dto).repository.id) }
            catch (e: Exception) { _syncMsg.value = msg(e) }
            finally { _opening.value = false }
        }
    }

    /** 把已加载的 GitHub 星标仓库逐个导入并加入本地收藏。 */
    fun syncStarredToFavorites() {
        if (syncing) return
        val list = starred.items.value
        if (list.isEmpty()) { _syncMsg.value = "还没有可同步的星标仓库"; return }
        syncing = true
        viewModelScope.launch {
            var ok = 0
            list.forEachIndexed { i, d ->
                _syncMsg.value = "正在同步 ${i + 1}/${list.size}：${d.name}"
                try {
                    c.repository.importRemote(d)
                    c.db.favoriteDao().add(FavoriteEntity(d.id, System.currentTimeMillis()))
                    ok++
                } catch (_: Exception) { }
            }
            _syncMsg.value = "同步完成：$ok/${list.size} 个星标仓库已加入收藏"
            syncing = false
        }
    }

    fun dismissMsg() { _syncMsg.value = null }
}

class ProfileVMFactory(private val c: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = ProfileViewModel(c) as T
}
