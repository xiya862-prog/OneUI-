package com.oneuirepo.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** 最近查看：每个仓库只保留最近一次查看时间。 */
@Entity(tableName = "view_history")
data class ViewHistoryEntity(@PrimaryKey val repositoryId: Long, val viewedAt: Long)

/** 仅通过「发现」页点开而导入的仓库：不进首页推荐，直到用户手动导入或收藏。 */
@Entity(tableName = "discovered")
data class DiscoveredEntity(@PrimaryKey val repositoryId: Long)
