package com.oneuirepo.app.ui.discover

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.ui.common.EmptyHint
import com.oneuirepo.app.ui.common.RemoteRepoCard
import com.oneuirepo.app.ui.common.UnderlineTabs

@Composable
fun DiscoverScreen(vm: StoreViewModel, onOpen: (Long) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    val opening by vm.opening.collectAsState()
    Column(Modifier.fillMaxSize()) {
        Spacer(Modifier.height(8.dp))
        UnderlineTabs(listOf("每日推荐", "排行榜"), tab) { tab = it }
        if (opening) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (tab == 0) ExploreFeed(vm, onOpen) else Charts(vm, onOpen)
    }
}

@Composable
private fun ExploreFeed(vm: StoreViewModel, onOpen: (Long) -> Unit) {
    val feed by vm.feed.collectAsState()
    val hasMore by vm.hasMore.collectAsState()
    val error by vm.error.collectAsState()
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("今日发现", style = MaterialTheme.typography.headlineMedium) }
        item {
            Text(
                "每天换一批可安装的应用，往下滑自动加载更多；点开可查看详情并自动归类（不会出现在首页推荐里）",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        items(feed, key = { it.id }) { d -> RemoteRepoCard(d) { vm.open(d, onOpen) } }
        item {
            val e = error
            if (e != null) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(e, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = { vm.retry() }) { Text("重试") }
                }
            } else if (hasMore) {
                LaunchedEffect(feed.size) { vm.loadMore() }
                Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                EmptyHint("今天的推荐看完啦，明天再来")
            }
        }
    }
}

@Composable
private fun Charts(vm: StoreViewModel, onOpen: (Long) -> Unit) {
    var type by remember { mutableStateOf(ChartType.HOT) }
    val charts by vm.charts.collectAsState()
    val loading by vm.loading.collectAsState()
    val error by vm.error.collectAsState()
    LaunchedEffect(type) { vm.loadChart(type) }
    val list = charts[type]
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ChartType.entries.forEach { t ->
                    FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t.title) })
                }
            }
        }
        if (list == null) {
            item {
                val e = error
                if (e != null) {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(e, color = MaterialTheme.colorScheme.error)
                        TextButton(onClick = { vm.loadChart(type) }) { Text("重试") }
                    }
                } else if (loading) {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }
            }
        } else {
            if (list.isEmpty()) item { EmptyHint("暂无数据") }
            itemsIndexed(list, key = { _, d -> d.id }) { i, d ->
                RemoteRepoCard(d, rank = i + 1) { vm.open(d, onOpen) }
            }
        }
    }
}
