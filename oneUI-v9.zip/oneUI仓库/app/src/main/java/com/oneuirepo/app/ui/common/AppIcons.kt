package com.oneuirepo.app.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

enum class IconKind { STAR, HEART, CLOCK, SEARCH, CHEVRON, BACK, FORK }

/** 纯矢量绘制的小图标，不依赖 emoji / 字体，所有机型显示一致。 */
@Composable
fun AppIcon(kind: IconKind, tint: Color, size: Dp = 20.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val u = this.size.minDimension / 24f
        val stroke = Stroke(2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (kind) {
            IconKind.STAR -> {
                val p = Path()
                for (i in 0 until 10) {
                    val r = if (i % 2 == 0) 11f else 4.7f
                    val a = -PI / 2 + i * PI / 5
                    val x = (12 + r * cos(a)).toFloat() * u
                    val y = (12.8 + r * sin(a)).toFloat() * u
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
                drawPath(p, tint)
            }
            IconKind.HEART -> {
                val p = Path().apply {
                    moveTo(12f * u, 21f * u)
                    cubicTo(2f * u, 14f * u, 1.5f * u, 8f * u, 5f * u, 5f * u)
                    cubicTo(8f * u, 2.8f * u, 11f * u, 4.5f * u, 12f * u, 7f * u)
                    cubicTo(13f * u, 4.5f * u, 16f * u, 2.8f * u, 19f * u, 5f * u)
                    cubicTo(22.5f * u, 8f * u, 22f * u, 14f * u, 12f * u, 21f * u)
                    close()
                }
                drawPath(p, tint)
            }
            IconKind.CLOCK -> {
                drawCircle(tint, 9.5f * u, Offset(12f * u, 12f * u), style = stroke)
                drawLine(tint, Offset(12f * u, 6.5f * u), Offset(12f * u, 12f * u), 2f * u, StrokeCap.Round)
                drawLine(tint, Offset(12f * u, 12f * u), Offset(16f * u, 14.5f * u), 2f * u, StrokeCap.Round)
            }
            IconKind.SEARCH -> {
                drawCircle(tint, 7f * u, Offset(10.5f * u, 10.5f * u), style = stroke)
                drawLine(tint, Offset(15.8f * u, 15.8f * u), Offset(21f * u, 21f * u), 2.2f * u, StrokeCap.Round)
            }
            IconKind.CHEVRON -> {
                val p = Path().apply { moveTo(9f * u, 5f * u); lineTo(16f * u, 12f * u); lineTo(9f * u, 19f * u) }
                drawPath(p, tint, style = stroke)
            }
            IconKind.BACK -> {
                val p = Path().apply { moveTo(15f * u, 5f * u); lineTo(8f * u, 12f * u); lineTo(15f * u, 19f * u) }
                drawPath(p, tint, style = stroke)
            }
            IconKind.FORK -> {
                drawCircle(tint, 2.4f * u, Offset(6f * u, 5f * u), style = stroke)
                drawCircle(tint, 2.4f * u, Offset(18f * u, 5f * u), style = stroke)
                drawCircle(tint, 2.4f * u, Offset(12f * u, 20f * u), style = stroke)
                val p = Path().apply {
                    moveTo(6f * u, 7.4f * u); lineTo(6f * u, 10f * u); lineTo(18f * u, 10f * u); lineTo(18f * u, 7.4f * u)
                    moveTo(12f * u, 10f * u); lineTo(12f * u, 17.6f * u)
                }
                drawPath(p, tint, style = stroke)
            }
        }
    }
}
