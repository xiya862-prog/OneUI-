package com.oneuirepo.app.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.oneuirepo.app.ui.common.Pill
import com.oneuirepo.app.ui.theme.cardBorder
import com.oneuirepo.app.ui.theme.cardShape

private fun open(c: Context, uri: Uri) {
    runCatching { c.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

private fun copy(c: Context, text: String) {
    (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("code", text))
}

@Composable
fun GitHubAccountCard(vm: GitHubAccountViewModel) {
    val context = LocalContext.current
    val profile by vm.profile.collectAsState()
    val ui by vm.ui.collectAsState()
    var advanced by remember { mutableStateOf(false) }
    var clientId by remember { mutableStateOf(vm.clientId) }
    var backend by remember { mutableStateOf(vm.backendUrl) }

    Card(
        Modifier.fillMaxWidth(),
        shape = cardShape(24.dp),
        border = cardBorder(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // ---- 头部：头像 / 状态 ----
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(
                    Modifier.size(56.dp).clip(CircleShape).background(Color(0xFF1F2328)),
                    contentAlignment = Alignment.Center
                ) {
                    val a = profile?.avatar.orEmpty()
                    if (a.isNotEmpty()) AsyncImage(a, null, Modifier.fillMaxSize())
                    else Text("G", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    val p = profile
                    if (p != null) {
                        Text(p.name.ifBlank { p.login }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("@${p.login}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("GitHub 账号", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("尚未登录", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (profile != null) Pill("已登录")
            }

            if (profile != null) {
                Text(
                    "已使用你的账号访问 GitHub API，同步额度从匿名的 60 次/小时提升到 5000 次/小时。",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedButton(onClick = { vm.logout() }, Modifier.fillMaxWidth()) { Text("退出登录") }
            } else {
                when (val s = ui) {
                    is LoginUi.WaitingDevice -> DeviceCodeBlock(s, onCopyOpen = {
                        copy(context, s.userCode); open(context, Uri.parse(s.verifyUri))
                    }, onCancel = vm::cancel)
                    LoginUi.WaitingBackend -> WaitingRow("请在浏览器里完成授权…", vm::cancel)
                    LoginUi.Starting -> WaitingRow("正在向 GitHub 申请验证码…", vm::cancel)
                    else -> {
                        Text(
                            "登录后可提升 API 速率限制，同步项目和 Release 更稳定。令牌只加密保存在本机。",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = { vm.startDeviceLogin(clientId) },
                            Modifier.fillMaxWidth().height(48.dp)
                        ) { Text("使用 GitHub 登录", fontWeight = FontWeight.Bold) }
                    }
                }
                if (ui is LoginUi.Error) {
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.errorContainer) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                            Text((ui as LoginUi.Error).message, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                            Text("✕", Modifier.padding(start = 8.dp).clip(CircleShape).clickableNoRipple { vm.dismissError() }, color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
                // ---- 高级 ----
                TextButton(onClick = { advanced = !advanced }, contentPadding = PaddingValues(0.dp)) {
                    Text(if (advanced) "收起高级设置 ˄" else "高级设置（Client ID / 自有后端） ˅", style = MaterialTheme.typography.labelLarge)
                }
                AnimatedVisibility(advanced) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            clientId, { clientId = it }, Modifier.fillMaxWidth(),
                            label = { Text("OAuth App Client ID") }, singleLine = true,
                            supportingText = { Text("需在 GitHub OAuth App 中勾选 Enable Device Flow") }
                        )
                        OutlinedTextField(
                            backend, { backend = it }, Modifier.fillMaxWidth(),
                            label = { Text("OAuth 后端 HTTPS 地址（可选）") }, singleLine = true,
                            placeholder = { Text("https://你的域名") }
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = { vm.saveConfig(clientId, backend) }) { Text("保存") }
                            OutlinedButton(onClick = {
                                vm.saveConfig(clientId, backend)
                                vm.prepareBackendLogin(backend)?.let { open(context, it) }
                            }) { Text("通过后端登录") }
                        }
                        Text(
                            "后端模式：App 会打开 {后端}/login?redirect_uri=com.oneuirepo.app://auth&state=…，" +
                                "后端完成 GitHub 授权后需跳转回 com.oneuirepo.app://auth?access_token=…&state=…（原样带回 state）。",
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceCodeBlock(s: LoginUi.WaitingDevice, onCopyOpen: () -> Unit, onCancel: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("在 GitHub 页面输入下面的验证码完成授权：", style = MaterialTheme.typography.bodySmall)
        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.fillMaxWidth()) {
            Text(
                s.userCode,
                Modifier.padding(vertical = 16.dp),
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Black,
                fontSize = 30.sp,
                letterSpacing = 4.sp,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
        Button(onClick = onCopyOpen, Modifier.fillMaxWidth().height(48.dp)) { Text("复制验证码并打开 GitHub", fontWeight = FontWeight.Bold) }
        WaitingRow("等待你在 GitHub 上确认…", onCancel)
    }
}

@Composable
private fun WaitingRow(text: String, onCancel: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
        TextButton(onClick = onCancel) { Text("取消") }
    }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier =
    this.then(Modifier.padding(4.dp)).clickable(onClick = onClick)
