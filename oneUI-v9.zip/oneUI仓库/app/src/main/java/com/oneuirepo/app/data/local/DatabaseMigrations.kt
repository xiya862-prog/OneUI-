package com.oneuirepo.app.data.local

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS sync_states (repositoryId INTEGER NOT NULL PRIMARY KEY, etag TEXT, lastCheckedAt INTEGER NOT NULL)")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS cves (id TEXT NOT NULL PRIMARY KEY, summary TEXT NOT NULL, severity TEXT, cvss REAL, publishedAt TEXT, modifiedAt TEXT, affectedVersions TEXT NOT NULL, fixedVersions TEXT NOT NULL, `references` TEXT NOT NULL, sourceUrl TEXT, syncedAt INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS repository_cve_cross_ref (repositoryId INTEGER NOT NULL, cveId TEXT NOT NULL, PRIMARY KEY(repositoryId,cveId))")
    }
}

val MIGRATION_3_4 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS view_history (repositoryId INTEGER NOT NULL PRIMARY KEY, viewedAt INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS discovered (repositoryId INTEGER NOT NULL PRIMARY KEY)")
    }
}
