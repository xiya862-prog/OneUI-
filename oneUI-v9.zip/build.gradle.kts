plugins {
    id("com.android.application") version "9.3.1" apply false
    // AGP 9+ 内置 Kotlin，不再需要 org.jetbrains.kotlin.android
    id("org.jetbrains.kotlin.plugin.compose") version "2.4.10" apply false
    id("org.jetbrains.kotlin.plugin.serialization") version "2.4.10" apply false
    id("com.google.devtools.ksp") version "2.3.11" apply false
}
