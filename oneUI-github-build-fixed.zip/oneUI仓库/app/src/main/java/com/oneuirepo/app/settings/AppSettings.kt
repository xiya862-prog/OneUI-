package com.oneuirepo.app.settings

import android.content.Context

class AppSettings(context:Context) {
    private val p=context.getSharedPreferences("settings",Context.MODE_PRIVATE)
    var autoSync:Boolean get()=p.getBoolean("autoSync",true) set(v){p.edit().putBoolean("autoSync",v).apply()}
    var notifications:Boolean get()=p.getBoolean("notifications",true) set(v){p.edit().putBoolean("notifications",v).apply()}
    var imageLoading:Boolean get()=p.getBoolean("imageLoading",true) set(v){p.edit().putBoolean("imageLoading",v).apply()}
}
