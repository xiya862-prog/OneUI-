package com.oneuirepo.app.ui.home
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.data.local.dao.RepositoryDao
import com.oneuirepo.app.data.local.entity.RepositoryEntity
import androidx.lifecycle.*
class HomeViewModel(dao:RepositoryDao):ViewModel(){val popular=dao.observePopular();val newest=dao.observeNewest();val updated=dao.observeRecentlyUpdated()}
class HomeVMFactory(private val d:RepositoryDao):ViewModelProvider.Factory{@Suppress("UNCHECKED_CAST")override fun<T:ViewModel>T.create(k:Class<T>):T=HomeViewModel(d)as T}
@Composable fun HomeScreen(vm:HomeViewModel){val p by vm.popular.collectAsState(initial=emptyList());val n by vm.newest.collectAsState(initial=emptyList());val u by vm.updated.collectAsState(initial=emptyList());LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("oneUI仓库",style=MaterialTheme.typography.headlineLarge)};item{Text("🔥 热门项目",style=MaterialTheme.typography.titleLarge)};items(p.take(5)){Card(it)};item{Text("🆕 最新项目",style=MaterialTheme.typography.titleLarge)};items(n.take(5)){Card(it)};item{Text("⭐ 高 Star",style=MaterialTheme.typography.titleLarge)};items(p.take(5)){Card(it)};item{Text("🔄 最近更新",style=MaterialTheme.typography.titleLarge)};items(u.take(5)){Card(it)}}}
@Composable private fun Card(x:RepositoryEntity){ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(x.fullName,style=MaterialTheme.typography.titleMedium);Text(x.description.orEmpty(),maxLines=2);Text("⭐ ${x.stars}  Fork ${x.forks}  ${x.language.orEmpty()}",style=MaterialTheme.typography.bodySmall)}}}
