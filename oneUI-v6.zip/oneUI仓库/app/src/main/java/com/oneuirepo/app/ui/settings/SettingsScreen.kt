package com.oneuirepo.app.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.oneuirepo.app.ui.theme.ThemeState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.cve.CveScheduler
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.settings.AppSettings
import com.oneuirepo.app.settings.DataManager
import com.oneuirepo.app.sync.SyncScheduler
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(container:AppContainer) {
    val context=LocalContext.current
    val settings=remember{AppSettings(context)}
    val scope=rememberCoroutineScope()
    var auto by remember{mutableStateOf(settings.autoSync)}
    var notify by remember{mutableStateOf(settings.notifications)}
    var images by remember{mutableStateOf(settings.imageLoading)}
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)) {
        Text("设置",style=MaterialTheme.typography.headlineMedium)
        SettingSwitch("自动同步","后台定期检查项目",auto){auto=it;settings.autoSync=it;if(it)SyncScheduler.schedule(context) else SyncScheduler.cancel(context)}
        SettingSwitch("通知","新 Release 通知",notify){notify=it;settings.notifications=it}
        SettingSwitch("图片加载","加载 GitHub 头像和项目图片",images){images=it;settings.imageLoading=it}
        HorizontalDivider()
        Text("外观",style=MaterialTheme.typography.titleMedium)
        SettingSwitch("Manga 漫画风","粗描边、纸张质感的漫画面板风格",ThemeState.manga){ThemeState.setManga(context,it)}
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
            listOf("跟随系统","日间","夜间","Nord").forEachIndexed{i,t->FilterChip(selected=ThemeState.mode==i,onClick={ThemeState.setMode(context,i)},label={Text(t)})}
        }
        HorizontalDivider()
        Button(onClick={SyncScheduler.runNow(context)}){Text("立即同步项目")}
        Button(onClick={CveScheduler.runNow(context)}){Text("立即同步 CVE")}
        OutlinedButton(onClick={scope.launch { DataManager.share(context,DataManager.exportJson(container.db)) }}){Text("导出数据")}
        HorizontalDivider()
        Text("缓存管理",style=MaterialTheme.typography.titleMedium)
        Text("GitHub API：匿名公共 API；如需高频同步，可在后续版本加入 Token 设置。",style=MaterialTheme.typography.bodySmall)
        Text("版本：1.0.0",style=MaterialTheme.typography.bodySmall)
    }
}
@Composable private fun SettingSwitch(title:String,desc:String,value:Boolean,onChange:(Boolean)->Unit){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Column(Modifier.weight(1f)){Text(title);Text(desc,style=MaterialTheme.typography.bodySmall)};Switch(value,onChange)}}
