package com.oneuirepo.app.ui.favorite

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.ui.common.EmptyHint
import com.oneuirepo.app.ui.common.RepoCard

@Composable
fun FavoriteScreen(db: AppDatabase, onOpen: (Long) -> Unit) {
    val items by db.repositoryDao().observeFavorites().collectAsState(initial = emptyList())
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("收藏", style = MaterialTheme.typography.headlineMedium) }
        if (items.isEmpty()) item { EmptyHint("还没有收藏项目，在项目详情页点「收藏」") }
        items(items, key = { it.id }) { r -> RepoCard(r) { onOpen(r.id) } }
    }
}
