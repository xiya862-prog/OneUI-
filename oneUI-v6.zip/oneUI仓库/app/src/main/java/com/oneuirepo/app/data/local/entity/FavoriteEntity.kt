package com.oneuirepo.app.data.local.entity
import androidx.room.Entity
@Entity(tableName="favorites",primaryKeys=["repositoryId"]) data class FavoriteEntity(val repositoryId:Long,val createdAt:Long)
