package com.oneuirepo.app.ui.cve

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.cve.CveEntity
import com.oneuirepo.app.data.local.AppDatabase

@Composable
fun CveScreen(db:AppDatabase) {
    var q by remember { mutableStateOf("") }
    val items by db.cveDao().search(q).collectAsState(initial=emptyList())
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        item { Text("CVE",style=MaterialTheme.typography.headlineMedium) }
        item { OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),label={Text("搜索 CVE / Samsung / One UI")},singleLine=true) }
        items(items) { CveCard(it) }
        if(items.isEmpty()) item { Text("暂无 CVE 数据；可在设置中执行 CVE 同步。") }
    }
}

@Composable private fun CveCard(x:CveEntity) {
    ElevatedCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
        Text(x.id,style=MaterialTheme.typography.titleMedium)
        Text(x.summary,maxLines=4)
        Text("${x.severity ?: "未知"}  ·  CVSS ${x.cvss?.toString() ?: "-"}",style=MaterialTheme.typography.bodySmall)
        Text("发布时间：${x.publishedAt ?: "-"}",style=MaterialTheme.typography.bodySmall)
    } }
}
