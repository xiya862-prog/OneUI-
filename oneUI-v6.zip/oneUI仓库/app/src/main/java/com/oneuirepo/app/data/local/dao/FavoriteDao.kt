package com.oneuirepo.app.data.local.dao

import androidx.room.*
import com.oneuirepo.app.data.local.entity.FavoriteEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FavoriteDao {
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE repositoryId=:id)") fun observeIsFavorite(id:Long): Flow<Boolean>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun add(x:FavoriteEntity)
    @Query("DELETE FROM favorites WHERE repositoryId=:id") suspend fun remove(id:Long)
}
