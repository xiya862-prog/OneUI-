package com.oneuirepo.app.data.local.entity
import androidx.room.Entity
@Entity(tableName="categories") data class CategoryEntity(@androidx.room.PrimaryKey val id:String,val name:String)
@Entity(tableName="repository_category_cross_ref",primaryKeys=["repositoryId","categoryId"]) data class RepositoryCategoryCrossRef(val repositoryId:Long,val categoryId:String)
