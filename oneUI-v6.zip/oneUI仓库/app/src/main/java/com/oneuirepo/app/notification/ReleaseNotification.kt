package com.oneuirepo.app.notification

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object ReleaseNotification {
    private const val CHANNEL = "new_releases"
    fun show(context: Context, repoName: String, tag: String) {
        if (android.os.Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "新 Release", NotificationManager.IMPORTANCE_DEFAULT))
        val notification = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("oneUI仓库：发现新 Release")
            .setContentText("$repoName · $tag")
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(context).notify((repoName + tag).hashCode(), notification)
    }
}
