package com.oneuirepo.app.data.repository

import android.content.Context
import androidx.room.Room
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.data.local.MIGRATION_1_2
import com.oneuirepo.app.data.local.MIGRATION_2_3
import com.oneuirepo.app.data.remote.GitHubClient
import com.oneuirepo.app.domain.classifier.ClassificationEngine

class AppContainer(c:Context){
    val db=Room.databaseBuilder(c,AppDatabase::class.java,"oneui_repository.db").addMigrations(MIGRATION_1_2, MIGRATION_2_3).build()
    val repository=GitHubRepository(GitHubClient.api,db,ClassificationEngine())
}
