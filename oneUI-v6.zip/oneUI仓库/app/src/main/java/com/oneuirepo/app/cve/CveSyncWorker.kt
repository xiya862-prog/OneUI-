package com.oneuirepo.app.cve

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.oneuirepo.app.data.remote.CveClient
import com.oneuirepo.app.data.repository.AppContainer

class CveSyncWorker(ctx:Context, params:WorkerParameters):CoroutineWorker(ctx,params) {
    override suspend fun doWork():Result = try {
        val c=AppContainer(applicationContext)
        val keywords=listOf("Samsung One UI","Samsung Android","SystemUI Samsung","Galaxy kernel")
        val repo=CveRepository(CveClient.api,c.db)
        keywords.forEach { repo.search(it) }
        Result.success()
    } catch(_:Throwable) { Result.retry() }
}
