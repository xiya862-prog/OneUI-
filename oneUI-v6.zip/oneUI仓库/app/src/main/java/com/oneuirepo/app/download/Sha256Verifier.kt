package com.oneuirepo.app.download

import android.content.Context
import android.net.Uri
import java.security.MessageDigest

object Sha256Verifier {
    fun verify(context:Context, uri:Uri, expected:String):Boolean {
        val normalized=expected.removePrefix("sha256:").trim().lowercase()
        if(normalized.isBlank()) return false
        val digest=MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buffer=ByteArray(1024*64)
            while(true){ val n=input.read(buffer); if(n<0) break; digest.update(buffer,0,n) }
        } ?: return false
        return digest.digest().joinToString("") { "%02x".format(it) } == normalized
    }
}
