package com.oneuirepo.app.cve

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cves")
data class CveEntity(
    @PrimaryKey val id: String,
    val summary: String,
    val severity: String?,
    val cvss: Double?,
    val publishedAt: String?,
    val modifiedAt: String?,
    val affectedVersions: String,
    val fixedVersions: String,
    val references: String,
    val sourceUrl: String?,
    val syncedAt: Long
)

@Entity(tableName = "repository_cve_cross_ref", primaryKeys = ["repositoryId", "cveId"])
data class RepositoryCveCrossRef(val repositoryId: Long, val cveId: String)
