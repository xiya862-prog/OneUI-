package com.oneuirepo.app.data.local.dao

import androidx.room.*
import com.oneuirepo.app.data.local.entity.RepositoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RepositoryDao {
    @Query("SELECT * FROM repositories ORDER BY stars DESC")
    fun observePopular(): Flow<List<RepositoryEntity>>
    @Query("SELECT id FROM repositories")
    suspend fun getAllIds(): List<Long>
    @Query("SELECT * FROM repositories ORDER BY createdAt DESC")
    fun observeNewest(): Flow<List<RepositoryEntity>>
    @Query("SELECT * FROM repositories ORDER BY updatedAt DESC")
    fun observeRecentlyUpdated(): Flow<List<RepositoryEntity>>
    @Query("SELECT * FROM repositories WHERE id=:id LIMIT 1")
    fun observeById(id: Long): Flow<RepositoryEntity?>
    @Query("SELECT * FROM repositories WHERE id=:id LIMIT 1")
    suspend fun findById(id: Long): RepositoryEntity?
    @Query("SELECT * FROM repositories WHERE fullName LIKE '%' || :q || '%' OR name LIKE '%' || :q || '%' OR owner LIKE '%' || :q || '%' OR description LIKE '%' || :q || '%' OR topics LIKE '%' || :q || '%' OR readme LIKE '%' || :q || '%' ORDER BY stars DESC")
    fun search(q: String): Flow<List<RepositoryEntity>>
    @Query("SELECT r.* FROM repositories r INNER JOIN favorites f ON r.id=f.repositoryId ORDER BY f.createdAt DESC")
    fun observeFavorites(): Flow<List<RepositoryEntity>>
    @Insert(onConflict=OnConflictStrategy.REPLACE)
    suspend fun upsert(e: RepositoryEntity)
    @Query("SELECT * FROM repositories WHERE fullName=:fullName LIMIT 1")
    suspend fun findByFullName(fullName: String): RepositoryEntity?
}
