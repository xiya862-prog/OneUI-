package com.oneuirepo.app.domain.model
import com.oneuirepo.app.data.local.entity.RepositoryEntity
data class ImportResult(val repository:RepositoryEntity,val categories:List<String>,val releaseCount:Int)
