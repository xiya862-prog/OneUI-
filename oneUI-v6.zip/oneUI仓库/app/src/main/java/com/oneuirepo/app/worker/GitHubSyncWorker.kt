package com.oneuirepo.app.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.notification.ReleaseNotification

class GitHubSyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            val container = AppContainer(applicationContext)
            container.db.repositoryDao().getAllIds().forEach { id ->
                val result = container.repository.syncExisting(id)
                if (result.changed && result.latestReleaseTag != null) {
                    val repo = container.db.repositoryDao().findById(id)
                    if (repo != null) ReleaseNotification.show(applicationContext, repo.fullName, result.latestReleaseTag)
                }
            }
            Result.success()
        } catch (_: Throwable) {
            Result.retry()
        }
    }
}
