package com.oneuirepo.app.data.local.entity
import androidx.room.Entity
@Entity(tableName="release_assets") data class ReleaseAssetEntity(@androidx.room.PrimaryKey val id:Long,val releaseId:Long,val name:String,val size:Long,val downloadUrl:String,val contentType:String?,val downloadCount:Int,val digest:String?,val fileType:String)
