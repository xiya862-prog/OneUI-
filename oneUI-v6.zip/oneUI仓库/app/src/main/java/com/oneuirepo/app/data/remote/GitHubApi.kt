package com.oneuirepo.app.data.remote
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query
@Serializable data class GitHubOwnerDto(val login:String,@SerialName("avatar_url") val avatarUrl:String?=null)
@Serializable data class GitHubLicenseDto(val key:String?=null,val name:String?=null)
@Serializable data class GitHubRepositoryDto(val id:Long,val name:String,@SerialName("full_name") val fullName:String,val owner:GitHubOwnerDto,val description:String?=null,@SerialName("html_url") val htmlUrl:String,@SerialName("stargazers_count") val stars:Int=0,@SerialName("forks_count") val forks:Int=0,@SerialName("watchers_count") val watchers:Int=0,val language:String?=null,val license:GitHubLicenseDto?=null,val topics:List<String> = emptyList(),@SerialName("created_at") val createdAt:String?=null,@SerialName("updated_at") val updatedAt:String?=null,val archived:Boolean=false,val visibility:String?=null)
@Serializable data class GitHubSearchDto(val items:List<GitHubRepositoryDto> = emptyList())
@Serializable data class GitHubReadmeDto(val content:String?=null,val encoding:String?=null)
@Serializable data class GitHubTopicsDto(val names:List<String> = emptyList())
@Serializable data class GitHubAssetDto(val id:Long,val name:String,val size:Long=0,@SerialName("browser_download_url") val browserDownloadUrl:String,@SerialName("content_type") val contentType:String?=null,@SerialName("download_count") val downloadCount:Int=0,val digest:String?=null)
@Serializable data class GitHubReleaseDto(val id:Long,@SerialName("tag_name") val tagName:String,val name:String?=null,val body:String?=null,@SerialName("published_at") val publishedAt:String?=null,@SerialName("html_url") val htmlUrl:String,val assets:List<GitHubAssetDto> = emptyList())
interface GitHubApi {
 @Headers("Accept: application/vnd.github+json","X-GitHub-Api-Version: 2022-11-28") @GET("repos/{owner}/{repo}") suspend fun getRepository(@Path("owner") owner:String,@Path("repo") repo:String):GitHubRepositoryDto
 @Headers("Accept: application/vnd.github+json","X-GitHub-Api-Version: 2022-11-28") @GET("repos/{owner}/{repo}") suspend fun getRepositoryResponse(@Path("owner") owner:String,@Path("repo") repo:String,@retrofit2.http.Header("If-None-Match") etag:String?=null):Response<GitHubRepositoryDto>
 @Headers("Accept: application/vnd.github+json","X-GitHub-Api-Version: 2022-11-28") @GET("repos/{owner}/{repo}/readme") suspend fun getReadme(@Path("owner") owner:String,@Path("repo") repo:String):GitHubReadmeDto
 @Headers("Accept: application/vnd.github+json","X-GitHub-Api-Version: 2022-11-28") @GET("repos/{owner}/{repo}/topics") suspend fun getTopics(@Path("owner") owner:String,@Path("repo") repo:String):GitHubTopicsDto
 @Headers("Accept: application/vnd.github+json","X-GitHub-Api-Version: 2022-11-28") @GET("repos/{owner}/{repo}/releases") suspend fun getReleases(@Path("owner") owner:String,@Path("repo") repo:String):List<GitHubReleaseDto>
 @Headers("Accept: application/vnd.github+json","X-GitHub-Api-Version: 2022-11-28") @GET("search/repositories") suspend fun searchRepositories(@Query("q") q:String,@Query("sort") sort:String?=null,@Query("order") order:String="desc",@Query("per_page") perPage:Int=20,@Query("page") page:Int=1):GitHubSearchDto
}
