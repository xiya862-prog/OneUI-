package com.oneuirepo.app.cve

import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.data.remote.CveApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CveRepository(private val api:CveApi, private val db:AppDatabase) {
    suspend fun search(keyword:String):List<CveEntity> = withContext(Dispatchers.IO) {
        val response=api.search(keyword)
        val items=response.vulnerabilities.map { v ->
            val c=v.cve
            val m=c.metrics?.cvssMetricV31?.firstOrNull()?.cvssData
            CveEntity(c.id,c.descriptions.firstOrNull { it.lang=="en" }?.value ?: c.descriptions.firstOrNull()?.value.orEmpty(),m?.baseSeverity,m?.baseScore,c.published,c.lastModified,"","",c.references.joinToString("\n") { it.url },"https://nvd.nist.gov/vuln/detail/${c.id}",System.currentTimeMillis())
        }
        db.cveDao().upsertAll(items)
        items
    }
}
