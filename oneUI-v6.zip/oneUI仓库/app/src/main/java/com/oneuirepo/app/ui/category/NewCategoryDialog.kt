package com.oneuirepo.app.ui.category

import androidx.compose.material3.*
import androidx.compose.runtime.*

@Composable
fun NewCategoryDialog(existing: Set<String>, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val name = text.trim()
    val error = when {
        name.length > 20 -> "名称最多 20 个字"
        name in existing -> "这个分类已经存在"
        else -> null
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("新建分类") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("分类名称") },
                singleLine = true,
                isError = error != null,
                supportingText = { if (error != null) Text(error) }
            )
        },
        confirmButton = {
            TextButton(enabled = name.isNotEmpty() && error == null, onClick = { onConfirm(name) }) { Text("创建") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}
