package com.oneuirepo.app.settings

import android.content.Context
import com.oneuirepo.app.data.local.AppDatabase
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

object DataManager {
    suspend fun exportJson(db:AppDatabase):String {
        val array=JSONArray()
        db.repositoryDao().observePopular().first().forEach { r ->
            array.put(JSONObject().apply {
                put("id",r.id); put("fullName",r.fullName); put("url",r.htmlUrl); put("description",r.description ?: "")
                put("stars",r.stars); put("forks",r.forks); put("language",r.language ?: "")
                put("topics",r.topics.split("\n").filter(String::isNotBlank)); put("oneUiVersions",r.oneUiVersions)
                put("androidVersions",r.androidVersions); put("deviceCompatibility",r.deviceCompatibility); put("requirements",r.requirements)
            })
        }
        return JSONObject().put("format","oneUI仓库/1").put("repositories",array).put("generatedAt",System.currentTimeMillis()).toString(2)
    }
    fun share(context:Context,text:String) {
        val intent=android.content.Intent(android.content.Intent.ACTION_SEND).apply { type="application/json"; putExtra(android.content.Intent.EXTRA_TEXT,text); addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK) }
        context.startActivity(android.content.Intent.createChooser(intent,"导出 oneUI仓库数据").addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
