package com.oneuirepo.app.data.local.dao

import androidx.room.*
import com.oneuirepo.app.cve.CveEntity
import com.oneuirepo.app.cve.RepositoryCveCrossRef
import kotlinx.coroutines.flow.Flow

@Dao
interface CveDao {
    @Query("SELECT * FROM cves ORDER BY publishedAt DESC") fun observeAll(): Flow<List<CveEntity>>
    @Query("SELECT * FROM cves WHERE id=:id LIMIT 1") fun observeById(id:String): Flow<CveEntity?>
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(items:List<CveEntity>)
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun link(item:RepositoryCveCrossRef)
    @Query("SELECT c.* FROM cves c INNER JOIN repository_cve_cross_ref x ON c.id=x.cveId WHERE x.repositoryId=:repoId ORDER BY c.publishedAt DESC") fun observeForRepository(repoId:Long):Flow<List<CveEntity>>
    @Query("SELECT id FROM cves WHERE id IN (:ids)") suspend fun existingIds(ids:List<String>):List<String>
    @Query("SELECT * FROM cves WHERE id LIKE '%' || :q || '%' OR summary LIKE '%' || :q || '%' ORDER BY publishedAt DESC") fun search(q:String):Flow<List<CveEntity>>
}
