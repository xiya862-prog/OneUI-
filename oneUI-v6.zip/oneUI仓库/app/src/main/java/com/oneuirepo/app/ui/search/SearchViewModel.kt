package com.oneuirepo.app.ui.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.oneuirepo.app.data.local.dao.RepositoryDao

class SearchViewModel(private val dao:RepositoryDao):ViewModel(){
    fun results(q:String)=dao.search(q)
}
class SearchVMFactory(private val dao:RepositoryDao):ViewModelProvider.Factory{
    @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T=SearchViewModel(dao) as T
}
