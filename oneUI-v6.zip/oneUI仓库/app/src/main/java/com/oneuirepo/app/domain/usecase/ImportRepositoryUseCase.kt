package com.oneuirepo.app.domain.usecase
import com.oneuirepo.app.data.repository.GitHubRepository
class ImportRepositoryUseCase(private val r:GitHubRepository){suspend operator fun invoke(url:String)=GitHubUrlParser.parse(url)?.let{r.import(it.owner,it.repo)}?:throw IllegalArgumentException("请输入有效的 GitHub 仓库地址")}
