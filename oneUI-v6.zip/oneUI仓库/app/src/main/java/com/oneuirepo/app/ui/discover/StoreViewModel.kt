package com.oneuirepo.app.ui.discover

import androidx.lifecycle.*
import com.oneuirepo.app.data.remote.GitHubRepositoryDto
import com.oneuirepo.app.data.repository.GitHubRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class ChartType(val title: String) { HOT("热门"), NEW("新上榜"), UPDATED("最近更新") }

class StoreViewModel(private val repo: GitHubRepository) : ViewModel() {
    private val topics = listOf(
        "android-app", "jetpack-compose", "material-design", "xposed-module",
        "magisk-module", "android-launcher", "kotlin-android", "android-tools"
    )
    private val day = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_YEAR)
    private val startIdx = day % topics.size
    private var topicIdx = startIdx
    private var page = 1

    private val _feed = MutableStateFlow<List<GitHubRepositoryDto>>(emptyList())
    val feed = _feed.asStateFlow()
    private val _hasMore = MutableStateFlow(true)
    val hasMore = _hasMore.asStateFlow()
    private val _loading = MutableStateFlow(false)
    val loading = _loading.asStateFlow()
    private val _error = MutableStateFlow<String?>(null)
    val error = _error.asStateFlow()
    private val _opening = MutableStateFlow(false)
    val opening = _opening.asStateFlow()
    private val _charts = MutableStateFlow<Map<ChartType, List<GitHubRepositoryDto>>>(emptyMap())
    val charts = _charts.asStateFlow()

    private fun msg(e: Exception): String =
        if (e is retrofit2.HttpException && (e.code() == 403 || e.code() == 429)) "GitHub 请求太频繁，请稍后再试"
        else "网络错误：" + (e.message ?: "未知")

    private fun daysAgo(n: Int): String {
        val c = java.util.Calendar.getInstance()
        c.add(java.util.Calendar.DAY_OF_YEAR, -n)
        return java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(c.time)
    }

    fun loadMore() {
        if (_loading.value || !_hasMore.value) return
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                val topic = topics[topicIdx % topics.size]
                val q = "topic:$topic stars:>30 archived:false"
                val seed = day * 100 + topicIdx * 10 + page
                val r = repo.searchRemote(q, "stars", page).shuffled(kotlin.random.Random(seed))
                val known = _feed.value.map { it.id }.toSet()
                _feed.value = _feed.value + r.filter { it.id !in known }
                if (r.size < 20 || page >= 3) {
                    topicIdx++
                    page = 1
                    if (topicIdx - startIdx >= topics.size) _hasMore.value = false
                } else {
                    page++
                }
            } catch (e: Exception) {
                _error.value = msg(e)
            } finally {
                _loading.value = false
            }
        }
    }

    fun retry() { _error.value = null; loadMore() }

    fun loadChart(t: ChartType) {
        if (_charts.value.containsKey(t)) return
        viewModelScope.launch {
            _loading.value = true
            _error.value = null
            try {
                val q = when (t) {
                    ChartType.HOT -> "topic:android-app stars:>500 archived:false"
                    ChartType.NEW -> "topic:android-app created:>${daysAgo(120)} stars:>20 archived:false"
                    ChartType.UPDATED -> "topic:android-app stars:>200 pushed:>${daysAgo(7)} archived:false"
                }
                val sort = if (t == ChartType.UPDATED) "updated" else "stars"
                val r = repo.searchRemote(q, sort, 1, 30)
                _charts.value = _charts.value + (t to r)
            } catch (e: Exception) {
                _error.value = msg(e)
            } finally {
                _loading.value = false
            }
        }
    }

    fun open(dto: GitHubRepositoryDto, onDone: (Long) -> Unit) {
        if (_opening.value) return
        viewModelScope.launch {
            _opening.value = true
            try {
                val res = repo.importRemote(dto)
                onDone(res.repository.id)
            } catch (e: Exception) {
                _error.value = msg(e)
            } finally {
                _opening.value = false
            }
        }
    }
}

class StoreVMFactory(private val r: GitHubRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = StoreViewModel(r) as T
}
