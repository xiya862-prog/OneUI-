package com.oneuirepo.app.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import retrofit2.http.GET
import retrofit2.http.Query

@Serializable data class NvdResponse(val vulnerabilities: List<NvdVulnerability> = emptyList())
@Serializable data class NvdVulnerability(val cve: NvdCve)
@Serializable data class NvdCve(
    val id: String,
    val descriptions: List<NvdDescription> = emptyList(),
    val metrics: NvdMetrics? = null,
    val published: String? = null,
    val lastModified: String? = null,
    val references: List<NvdReference> = emptyList()
)
@Serializable data class NvdDescription(val lang:String, val value:String)
@Serializable data class NvdReference(val url:String)
@Serializable data class NvdMetrics(val cvssMetricV31: List<NvdMetricV31> = emptyList())
@Serializable data class NvdMetricV31(val cvssData:NvdCvss)
@Serializable data class NvdCvss(val baseScore:Double?=null, val baseSeverity:String?=null)

interface CveApi {
    @GET("rest/json/cves/2.0")
    suspend fun search(@Query("keywordSearch") keyword:String, @Query("resultsPerPage") results:Int=20):NvdResponse
}
