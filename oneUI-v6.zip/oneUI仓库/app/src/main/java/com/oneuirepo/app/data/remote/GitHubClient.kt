package com.oneuirepo.app.data.remote
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
object GitHubClient { val api:GitHubApi by lazy { Retrofit.Builder().baseUrl("https://api.github.com/").addConverterFactory(Json{ignoreUnknownKeys=true}.asConverterFactory("application/json".toMediaType())).build().create(GitHubApi::class.java) } }
