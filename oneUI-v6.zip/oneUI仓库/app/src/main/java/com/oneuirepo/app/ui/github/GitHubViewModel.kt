package com.oneuirepo.app.ui.github
import androidx.lifecycle.*
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.domain.usecase.ImportRepositoryUseCase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
sealed interface ImportState{data object Idle:ImportState;data object Loading:ImportState;data class Success(val value:com.oneuirepo.app.domain.model.ImportResult):ImportState;data class Error(val message:String):ImportState}
class GitHubViewModel(c:AppContainer):ViewModel(){private val _state=MutableStateFlow<ImportState>(ImportState.Idle);val state=_state.asStateFlow();private val use=ImportRepositoryUseCase(c.repository);fun import(url:String){viewModelScope.launch{_state.value=ImportState.Loading;_state.value=runCatching{use(url)}.fold({ImportState.Success(it)},{ImportState.Error(it.message?:"导入失败")})}}}
class GitHubViewModelFactory(private val c:AppContainer):ViewModelProvider.Factory{@Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T=GitHubViewModel(c) as T}
