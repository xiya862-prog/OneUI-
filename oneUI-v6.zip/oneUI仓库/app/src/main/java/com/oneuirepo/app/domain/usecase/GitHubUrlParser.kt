package com.oneuirepo.app.domain.usecase
import android.net.Uri
data class GitHubRepoPath(val owner:String,val repo:String)
object GitHubUrlParser{fun parse(raw:String):GitHubRepoPath?{val u=runCatching{Uri.parse(raw.trim())}.getOrNull()?:return null;if(!u.scheme.equals("https",true)||!u.host.equals("github.com",true))return null;val p=u.pathSegments.filter{it.isNotBlank()};if(p.size<2)return null;return GitHubRepoPath(p[0],p[1].removeSuffix(".git"))}}
