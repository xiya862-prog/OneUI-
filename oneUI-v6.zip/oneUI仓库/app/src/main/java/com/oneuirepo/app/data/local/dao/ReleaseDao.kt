package com.oneuirepo.app.data.local.dao

import androidx.room.*
import com.oneuirepo.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ReleaseDao {
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(x:List<ReleaseEntity>)
    @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAssets(x:List<ReleaseAssetEntity>)
    @Query("SELECT * FROM releases WHERE repositoryId=:repoId ORDER BY publishedAt DESC") fun observeReleases(repoId:Long): Flow<List<ReleaseEntity>>
    @Query("SELECT * FROM release_assets WHERE releaseId IN (SELECT id FROM releases WHERE repositoryId=:repoId) ORDER BY id DESC") fun observeAssets(repoId:Long): Flow<List<ReleaseAssetEntity>>
    @Query("SELECT * FROM releases WHERE repositoryId=:repoId ORDER BY publishedAt DESC LIMIT 1") suspend fun findLatest(repoId:Long): ReleaseEntity?
    @Query("DELETE FROM release_assets WHERE releaseId IN (SELECT id FROM releases WHERE repositoryId=:repoId)") suspend fun deleteAssets(repoId:Long)
    @Query("DELETE FROM releases WHERE repositoryId=:repoId") suspend fun deleteReleases(repoId:Long)
}
