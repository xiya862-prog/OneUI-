package com.oneuirepo.app.data.local.entity
import androidx.room.Entity
@Entity(tableName="releases") data class ReleaseEntity(@androidx.room.PrimaryKey val id:Long,val repositoryId:Long,val tagName:String,val name:String?,val body:String?,val publishedAt:String?,val htmlUrl:String)
