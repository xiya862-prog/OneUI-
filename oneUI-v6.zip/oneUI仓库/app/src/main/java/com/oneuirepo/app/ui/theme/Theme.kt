package com.oneuirepo.app.ui.theme

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.settings.AppSettings

object ThemeState {
    var manga by mutableStateOf(false)
    var mode by mutableStateOf(0) // 0 跟随系统 1 日间 2 夜间 3 Nord

    fun load(c: Context) {
        val s = AppSettings(c)
        manga = s.mangaStyle
        mode = s.themeMode
    }

    fun setManga(c: Context, v: Boolean) { manga = v; AppSettings(c).mangaStyle = v }
    fun setMode(c: Context, v: Int) { mode = v; AppSettings(c).themeMode = v }
}

@Composable
fun cardShape(radius: Dp = 22.dp): Shape = if (ThemeState.manga) RoundedCornerShape(6.dp) else RoundedCornerShape(radius)

@Composable
fun cardBorder(): BorderStroke? = if (ThemeState.manga) BorderStroke(2.dp, MaterialTheme.colorScheme.onSurface) else null

@Composable
fun Modifier.mangaBorder(shape: Shape): Modifier =
    if (ThemeState.manga) this.border(2.dp, MaterialTheme.colorScheme.onSurface, shape) else this

private val AppLight = lightColorScheme(
    primary = Color(0xFF3E9A55), onPrimary = Color.White,
    primaryContainer = Color(0xFFD7F0DD), onPrimaryContainer = Color(0xFF0B3D1A),
    secondaryContainer = Color(0xFFE6EEE8), onSecondaryContainer = Color(0xFF1B3A24),
    tertiary = Color(0xFF3D8FC4),
    background = Color(0xFFF1F1F6), surface = Color.White, onSurface = Color(0xFF1A1A1A),
    surfaceVariant = Color(0xFFE9E9EF), onSurfaceVariant = Color(0xFF6B6B73)
)

private val AppDark = darkColorScheme(
    primary = Color(0xFF6BCB84), onPrimary = Color(0xFF00210C),
    primaryContainer = Color(0xFF1F4D2E), onPrimaryContainer = Color(0xFFD7F0DD),
    secondaryContainer = Color(0xFF26332A), onSecondaryContainer = Color(0xFFDDE8DF),
    tertiary = Color(0xFF7CC4F0),
    background = Color.Black, surface = Color(0xFF151517), onSurface = Color(0xFFEDEDED),
    surfaceVariant = Color(0xFF232326), onSurfaceVariant = Color(0xFFA0A0A8)
)

private val NordScheme = darkColorScheme(
    primary = Color(0xFF88C0D0), onPrimary = Color(0xFF2E3440),
    primaryContainer = Color(0xFF434C5E), onPrimaryContainer = Color(0xFFECEFF4),
    secondaryContainer = Color(0xFF434C5E), onSecondaryContainer = Color(0xFFECEFF4),
    tertiary = Color(0xFFA3BE8C),
    background = Color(0xFF2E3440), surface = Color(0xFF3B4252), onSurface = Color(0xFFECEFF4),
    surfaceVariant = Color(0xFF434C5E), onSurfaceVariant = Color(0xFFD8DEE9)
)

private val MangaDay = lightColorScheme(
    primary = Color(0xFFE63946), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFD23F), onPrimaryContainer = Color(0xFF111111),
    secondaryContainer = Color(0xFFF7E3A1), onSecondaryContainer = Color(0xFF111111),
    tertiary = Color(0xFF1D3557),
    background = Color(0xFFF3EAD3), surface = Color(0xFFFFFBF0), onSurface = Color(0xFF111111),
    surfaceVariant = Color(0xFFE8DDC0), onSurfaceVariant = Color(0xFF4A4436)
)

private val MangaNight = darkColorScheme(
    primary = Color(0xFFFFD23F), onPrimary = Color(0xFF111111),
    primaryContainer = Color(0xFFE63946), onPrimaryContainer = Color.White,
    secondaryContainer = Color(0xFF3A3326), onSecondaryContainer = Color(0xFFF3EAD3),
    tertiary = Color(0xFF8ECAE6),
    background = Color(0xFF141414), surface = Color(0xFF1F1F1F), onSurface = Color(0xFFF3EAD3),
    surfaceVariant = Color(0xFF2A2A2A), onSurfaceVariant = Color(0xFFCFC6AE)
)

private val MangaShapes = Shapes(
    extraSmall = RoundedCornerShape(2.dp), small = RoundedCornerShape(4.dp),
    medium = RoundedCornerShape(6.dp), large = RoundedCornerShape(8.dp), extraLarge = RoundedCornerShape(10.dp)
)

private fun mangaTypography(): Typography {
    val b = Typography()
    return b.copy(
        headlineLarge = b.headlineLarge.copy(fontWeight = FontWeight.Black),
        headlineMedium = b.headlineMedium.copy(fontWeight = FontWeight.Black),
        titleLarge = b.titleLarge.copy(fontWeight = FontWeight.Black),
        titleMedium = b.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
        labelLarge = b.labelLarge.copy(fontWeight = FontWeight.ExtraBold)
    )
}

@Composable
fun OneUITheme(content: @Composable () -> Unit) {
    val sysDark = isSystemInDarkTheme()
    val mode = ThemeState.mode
    val manga = ThemeState.manga
    val scheme = when {
        mode == 3 -> NordScheme
        mode == 2 || (mode == 0 && sysDark) -> if (manga) MangaNight else AppDark
        else -> if (manga) MangaDay else AppLight
    }
    MaterialTheme(
        colorScheme = scheme,
        typography = if (manga) mangaTypography() else Typography(),
        shapes = if (manga) MangaShapes else Shapes(),
        content = content
    )
}
