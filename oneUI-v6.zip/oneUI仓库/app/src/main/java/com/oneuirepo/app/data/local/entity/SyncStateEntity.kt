package com.oneuirepo.app.data.local.entity

import androidx.room.Entity

@Entity(tableName = "sync_states")
data class SyncStateEntity(
    @androidx.room.PrimaryKey val repositoryId: Long,
    val etag: String? = null,
    val lastCheckedAt: Long = 0L
)
