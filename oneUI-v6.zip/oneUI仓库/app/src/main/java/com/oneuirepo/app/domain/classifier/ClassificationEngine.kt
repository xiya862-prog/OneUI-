package com.oneuirepo.app.domain.classifier
class ClassificationEngine {
 val allCategories=listOf("One UI 9","One UI 8.5","One UI 8.0","SystemUI","RRO","主题","字体","模块","LSPosed","Shizuku","Root","KernelSU","Magisk","DeX","折叠屏","Watch","CVE")
 private val rules=mapOf("One UI 9" to listOf("one ui 9","oneui9"),"One UI 8.5" to listOf("one ui 8.5","oneui8.5"),"One UI 8.0" to listOf("one ui 8","oneui8"),"SystemUI" to listOf("systemui","system ui"),"RRO" to listOf("rro","runtime resource overlay","overlay"),"主题" to listOf("theme","theming","icon","wallpaper","aod"),"字体" to listOf("font","typeface"),"模块" to listOf("module","magisk module","ksu module"),"LSPosed" to listOf("lsposed"),"Shizuku" to listOf("shizuku"),"Root" to listOf("root","superuser"),"KernelSU" to listOf("kernelsu","ksu module"),"Magisk" to listOf("magisk"),"DeX" to listOf("samsung dex","samsung-dex","dex"),"折叠屏" to listOf("foldable","flex mode","cover screen","fold5","fold6","fold7"),"Watch" to listOf("galaxy watch","wear os","watch"),"CVE" to listOf("cve-"))
 fun classify(text:String):Set<String>{val t=text.lowercase();return rules.filterValues{ks->ks.any(t::contains)}.keys}
 fun androidVersions(t:String)=Regex("Android\\s+\\d{1,2}",RegexOption.IGNORE_CASE).findAll(t).map{it.value}.toSet()
 fun devices(t:String)=Regex("(?:Galaxy\\s+)?(?:S\\d{2}|Z\\s?(?:Fold|Flip)\\s?\\d+|Fold\\d+|Flip\\d+)",RegexOption.IGNORE_CASE).findAll(t).map{it.value}.toSet()
 fun requirements(r:String?)=r.orEmpty().lineSequence().filter{it.contains("require",true)||it.contains("要求")||it.contains("需要")}.take(20).joinToString("\n")
}
