package com.oneuirepo.app.sync

import android.content.Context
import androidx.work.*
import com.oneuirepo.app.worker.GitHubSyncWorker
import java.util.concurrent.TimeUnit

object SyncScheduler {
    private const val NAME = "oneui-github-periodic-sync"
    fun schedule(context: Context, hours: Long = 6L) {
        val request = PeriodicWorkRequestBuilder<GitHubSyncWorker>(hours, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, request)
    }
    fun runNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<GitHubSyncWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(context).enqueue(request)
    }
    fun cancel(context:Context) { WorkManager.getInstance(context).cancelUniqueWork(NAME) }
}

