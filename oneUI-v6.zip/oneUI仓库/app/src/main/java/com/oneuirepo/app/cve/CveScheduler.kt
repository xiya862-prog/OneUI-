package com.oneuirepo.app.cve

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

object CveScheduler {
    private const val NAME="oneui_cve_sync"
    fun schedule(context:Context) {
        val req=PeriodicWorkRequestBuilder<CveSyncWorker>(24,TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,30,TimeUnit.SECONDS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(NAME,ExistingPeriodicWorkPolicy.UPDATE,req)
    }
    fun runNow(context:Context) {
        val req=OneTimeWorkRequestBuilder<CveSyncWorker>().setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(context).enqueue(req)
    }
}
