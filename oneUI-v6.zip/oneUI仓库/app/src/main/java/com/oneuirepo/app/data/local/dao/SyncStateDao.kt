package com.oneuirepo.app.data.local.dao

import androidx.room.*
import com.oneuirepo.app.data.local.entity.SyncStateEntity

@Dao
interface SyncStateDao {
    @Query("SELECT * FROM sync_states WHERE repositoryId=:id LIMIT 1")
    suspend fun find(id: Long): SyncStateEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(value: SyncStateEntity)
}
