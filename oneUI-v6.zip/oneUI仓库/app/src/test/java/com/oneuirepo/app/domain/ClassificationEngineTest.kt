package com.oneuirepo.app.domain

import com.oneuirepo.app.domain.classifier.ClassificationEngine
import org.junit.Assert.assertTrue
import org.junit.Test

class ClassificationEngineTest {
    @Test fun samsungKsuProjectGetsExpectedCategories() {
        val result=ClassificationEngine().classify("One UI 9 SystemUI KernelSU RRO Shizuku")
        assertTrue(result.contains("One UI 9"))
        assertTrue(result.contains("SystemUI"))
        assertTrue(result.contains("KernelSU"))
        assertTrue(result.contains("RRO"))
        assertTrue(result.contains("Shizuku"))
    }
}
