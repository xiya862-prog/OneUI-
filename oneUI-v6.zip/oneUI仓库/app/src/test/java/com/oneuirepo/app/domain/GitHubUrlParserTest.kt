package com.oneuirepo.app.domain

import com.oneuirepo.app.domain.usecase.GitHubUrlParser
import org.junit.Assert.assertEquals
import org.junit.Test

class GitHubUrlParserTest {
    @Test fun parsesRepositoryUrl() {
        val x=GitHubUrlParser.parse("https://github.com/example/project")!!
        assertEquals("example",x.owner)
        assertEquals("project",x.repo)
    }
}
