# GitHub Actions 构建 APK

本工程已经加入 `.github/workflows/build-apk.yml`。

## 自动构建

推送到 `main` / `master`、提交 Pull Request，或在 GitHub Actions 中手动运行 `Build APK`，都会执行：

1. JDK 17
2. Android SDK
3. Android API 37
4. Build Tools 36.0.0
5. Gradle 9.5.0
6. `:app:assembleDebug`
7. `:app:testDebugUnitTest`
8. 上传 `app-debug.apk` Artifact

## 发布 APK

创建并推送版本标签，例如：

```bash
git tag v1.0.0
git push origin v1.0.0
```

GitHub Actions 会构建 APK，并自动创建 GitHub Release，把 `app-debug.apk` 上传到 Release。

## 注意

当前工程使用 Android Gradle Plugin 9.3.1，因此 CI 固定使用 Gradle 9.5.0。Android 官方兼容表显示 AGP 9.3 至少需要 Gradle 9.5.0。
