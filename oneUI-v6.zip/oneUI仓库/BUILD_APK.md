# 构建 APK

## Android Studio
1. 使用当前版本 Android Studio 打开本目录。
2. 安装 Android SDK Platform 37 与对应 Build Tools。
3. 等待 Gradle Sync 完成。
4. 执行 `:app:assembleDebug`。
5. APK 输出：`app/build/outputs/apk/debug/app-debug.apk`。

## 命令行
在具有 Gradle 9.x、JDK 17+、Android SDK 37 的环境执行：

```bash
gradle :app:assembleDebug
```

Release 构建：

```bash
gradle :app:assembleRelease
```

Release APK 需要配置正式签名后再发布。
