# oneUI仓库

Samsung One UI / Android modding / Root / module / CVE GitHub repository aggregator.

## Final scope
- 5 bottom navigation pages: 首页 / 分类 / GitHub / 收藏 / 设置
- 17 fixed categories: One UI 9, One UI 8.5, One UI 8.0, SystemUI, RRO, 主题, 字体, 模块, LSPosed, Shizuku, Root, KernelSU, Magisk, DeX, 折叠屏, Watch, CVE
- GitHub URL automatic import and update
- README / Topics / Release / APK / ZIP / JAR parsing
- automatic classification with Android/device/requirements extraction
- Room local cache
- global repository search
- repository details and favorites
- Android DownloadManager integration
- SHA-256 verification helper
- WorkManager background sync with ETag
- new Release notifications
- NVD CVE synchronization and CVE ↔ repository association
- data export

## Build
Open this directory in Android Studio with a current Android SDK and Gradle-compatible environment. The project targets SDK 37, min SDK 26.

The supplied environment did not contain an Android SDK or Gradle distribution, so APK compilation must be performed in an Android build environment.
