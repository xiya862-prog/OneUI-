package com.oneuirepo.app

import android.Manifest
import android.os.Bundle
import android.content.Intent
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.oneuirepo.app.auth.GitHubAuth
import kotlinx.coroutines.launch
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.sync.SyncScheduler
import com.oneuirepo.app.cve.CveScheduler
import com.oneuirepo.app.ui.OneUIRepoApp

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        handleGitHubCallback(intent)
        SyncScheduler.schedule(applicationContext)
        CveScheduler.schedule(applicationContext)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val c = AppContainer(applicationContext)
        com.oneuirepo.app.ui.theme.ThemeState.load(applicationContext)
        setContent {
            com.oneuirepo.app.ui.theme.OneUITheme {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { OneUIRepoApp(c) }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleGitHubCallback(intent)
    }

    private fun handleGitHubCallback(intent: Intent?) {
        val uri = intent?.data ?: return
        if (uri.scheme != GitHubAuth.CALLBACK_SCHEME || uri.host != GitHubAuth.CALLBACK_HOST ||
            uri.path != "/callback") return
        lifecycleScope.launch {
            GitHubAuth.finishLogin(applicationContext, uri)
                .onSuccess { Toast.makeText(applicationContext, "GitHub 登录成功：$it", Toast.LENGTH_LONG).show() }
                .onFailure { Toast.makeText(applicationContext, "GitHub 登录失败：${it.message}", Toast.LENGTH_LONG).show() }
        }
    }
}
