package com.oneuirepo.app.auth

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Mobile OAuth bridge. The backend owns GitHub client_secret and performs the OAuth code exchange.
 * Configure backendBaseUrl to your HTTPS backend before using this feature.
 */
object GitHubAuth {
    const val CALLBACK_SCHEME = "oneuirepo"
    const val CALLBACK_HOST = "oauth"
    private const val PREFS = "github_auth"
    private const val KEY_BACKEND = "backend_base_url"
    private const val KEY_SESSION = "app_session"
    private const val KEY_LOGIN = "login"

    private fun prefs(context: Context) = EncryptedSharedPreferences.create(
        context,
        PREFS,
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun backendBaseUrl(context: Context): String =
        prefs(context)
            .getString(KEY_BACKEND, "")?.trim()?.trimEnd('/') ?: ""

    fun setBackendBaseUrl(context: Context, value: String) {
        prefs(context)
            .edit().putString(KEY_BACKEND, value.trim().trimEnd('/')).apply()
    }

    fun loginName(context: Context): String? =
        prefs(context).getString(KEY_LOGIN, null)

    fun isSignedIn(context: Context): Boolean =
        !prefs(context).getString(KEY_SESSION, null).isNullOrBlank()

    fun signOut(context: Context) {
        prefs(context).edit()
            .remove(KEY_SESSION).remove(KEY_LOGIN).apply()
    }

    fun startLogin(context: Context): Result<Unit> = runCatching {
        val base = backendBaseUrl(context)
        require(base.startsWith("https://")) { "请先填写 HTTPS 登录后端地址" }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("$base/auth/github/start"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    /**
     * The backend redirects to oneuirepo://oauth/callback?ticket=ONE_TIME_TICKET.
     * The one-time ticket must expire quickly and be atomically consumed by the backend.
     */
    suspend fun finishLogin(context: Context, callback: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            require(callback.scheme == CALLBACK_SCHEME && callback.host == CALLBACK_HOST) { "无效的登录回调" }
            val ticket = callback.getQueryParameter("ticket").orEmpty()
            require(ticket.isNotBlank() && ticket.length <= 2048) { "登录票据缺失或无效" }
            val base = backendBaseUrl(context)
            require(base.startsWith("https://")) { "登录后端地址未配置或不是 HTTPS" }
            val conn = (URL("$base/auth/mobile/exchange").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 15000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
            }
            try {
                conn.outputStream.use {
                    it.write(JSONObject().put("ticket", ticket).toString().toByteArray(Charsets.UTF_8))
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                check(code in 200..299) { "登录交换失败（HTTP $code）" }
                val json = JSONObject(body)
                val session = json.optString("session_token")
                val login = json.optString("login", "GitHub 用户")
                require(session.isNotBlank()) { "后端未返回应用会话" }
                prefs(context).edit()
                    .putString(KEY_SESSION, session).putString(KEY_LOGIN, login).apply()
                login
            } finally {
                conn.disconnect()
            }
        }
    }
}
