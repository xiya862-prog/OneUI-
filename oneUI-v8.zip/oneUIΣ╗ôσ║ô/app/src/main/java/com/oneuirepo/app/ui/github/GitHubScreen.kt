package com.oneuirepo.app.ui.github

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import com.oneuirepo.app.auth.GitHubAuth
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.oneuirepo.app.ui.search.*
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.domain.model.ImportResult

@Composable fun GitHubScreen(vm:GitHubViewModel,container:AppContainer,onOpen:(Long)->Unit){
    val context = LocalContext.current
    var backendUrl by remember { mutableStateOf(GitHubAuth.backendBaseUrl(context)) }
    var authRefresh by remember { mutableIntStateOf(0) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) authRefresh++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    val signedIn = remember(authRefresh) { GitHubAuth.isSignedIn(context) }
    val accountName = remember(authRefresh) { GitHubAuth.loginName(context) }
    val s:SearchViewModel=viewModel(factory=SearchVMFactory(container.db.repositoryDao()))
    var url by remember{mutableStateOf("")}; var query by remember{mutableStateOf("")}
    val results by s.results(query).collectAsState(initial=emptyList())
    val state by vm.state.collectAsState()
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item {
            Text("GitHub", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(8.dp))
            Text("账号登录", style = MaterialTheme.typography.titleMedium)
            Text(
                if (signedIn) "已登录：${accountName ?: "GitHub 用户"}" else "尚未登录",
                style = MaterialTheme.typography.bodyMedium
            )
            OutlinedTextField(
                value = backendUrl,
                onValueChange = { backendUrl = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("OAuth 后端 HTTPS 地址") },
                placeholder = { Text("https://api.example.com") },
                singleLine = true
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    if (!backendUrl.startsWith("https://")) {
                        Toast.makeText(context, "必须使用 HTTPS 后端地址", Toast.LENGTH_LONG).show()
                    } else {
                        GitHubAuth.setBackendBaseUrl(context, backendUrl)
                        Toast.makeText(context, "后端地址已保存", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("保存地址") }
                Button(onClick = {
                    GitHubAuth.setBackendBaseUrl(context, backendUrl)
                    GitHubAuth.startLogin(context).onFailure {
                        Toast.makeText(context, it.message ?: "无法启动登录", Toast.LENGTH_LONG).show()
                    }
                }) { Text("使用 GitHub 登录") }
                if (signedIn) {
                    OutlinedButton(onClick = {
                        GitHubAuth.signOut(context)
                        authRefresh++
                    }) { Text("退出") }
                }
            }
        }
        item{OutlinedTextField(url,{url=it},modifier=Modifier.fillMaxWidth(),label={Text("GitHub 仓库地址")},singleLine=true)}
        item{Button(onClick={vm.import(url)},enabled=url.isNotBlank()){Text("自动导入 / 更新")}}
        item{when(val x=state){ is ImportState.Success->Text("导入成功：${x.value.repository.fullName} · ${x.value.releaseCount} 个 Release"); is ImportState.Error->Text("导入失败：${x.message}"); ImportState.Loading->Text("正在读取 GitHub..."); else->Unit }}
        item{OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),label={Text("搜索项目")},singleLine=true)}
        items(results,key={it.id}){r->com.oneuirepo.app.ui.common.RepoCard(r){onOpen(r.id)}}
    }
}
