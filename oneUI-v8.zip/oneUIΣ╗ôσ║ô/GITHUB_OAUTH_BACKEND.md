# oneUI仓库 GitHub 登录后端接口约定

Android 端已加入浏览器登录入口、`oneuirepo://oauth/callback` 回调、一次性票据交换及加密本地会话存储。**登录真正可用前，必须部署此后端并填写 HTTPS 地址。** 本 ZIP 不包含 GitHub App 的 client secret，也不能在没有后端配置时完成真实登录。

## 流程

1. APP 用系统浏览器打开 `GET /auth/github/start`。
2. 后端创建随机 `state` 和 PKCE（如使用 GitHub OAuth App，需按 GitHub 当前支持能力实现并验证），将用户导向 GitHub 授权页面。
3. GitHub 回调到后端；后端校验 `state`，在服务端用 client secret 交换 GitHub access token，并获取 `/user`。
4. 后端创建短时、一次性、不可猜测的 ticket，然后重定向到 `oneuirepo://oauth/callback?ticket=...`。
5. APP 将 ticket 通过 `POST /auth/mobile/exchange` 发送给后端。
6. 后端原子消费 ticket，返回 JSON：`{"session_token":"<短期应用会话>","login":"github-login"}`。

## 安全要求

- GitHub `client_secret` 只能存放在服务端环境变量/密钥管理服务中，禁止放进 APK、仓库或日志。
- 只允许 HTTPS；服务端必须严格校验 `state`，回调 URI 使用精确白名单。
- ticket 应至少 256 位随机性，建议 60 秒内过期、只能消费一次，并在数据库/Redis 中原子消费。
- 应用会话应短期、可撤销；写仓库操作由后端执行并进行授权、仓库归属及输入校验。
- GitHub 授权权限遵循最小权限原则。创建仓库、提交/修改文件需要相应写权限；不需要写操作时不要申请。
- `POST /auth/mobile/exchange` 请求体：`{"ticket":"..."}`。成功返回 `session_token` 和 `login`；失败返回非 2xx。
- 退出登录目前清除 APP 本地会话；生产后端还应提供会话撤销接口。
