package com.oneuirepo.app

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.sync.SyncScheduler
import com.oneuirepo.app.cve.CveScheduler
import com.oneuirepo.app.ui.OneUIRepoApp

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SyncScheduler.schedule(applicationContext)
        CveScheduler.schedule(applicationContext)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val c = AppContainer(applicationContext)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { OneUIRepoApp(c) } } }
    }
}
