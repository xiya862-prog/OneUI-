package com.oneuirepo.app.ui.github

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.oneuirepo.app.ui.search.*
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.domain.model.ImportResult

@Composable fun GitHubScreen(vm:GitHubViewModel,container:AppContainer,onOpen:(Long)->Unit){
    val s:SearchViewModel=viewModel(factory=SearchVMFactory(container.db.repositoryDao()))
    var url by remember{mutableStateOf("")}; var query by remember{mutableStateOf("")}
    val results by s.results(query).collectAsState(initial=emptyList())
    val state by vm.state.collectAsState()
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("GitHub",style=MaterialTheme.typography.headlineMedium)}
        item{OutlinedTextField(url,{url=it},modifier=Modifier.fillMaxWidth(),label={Text("GitHub 仓库地址")},singleLine=true)}
        item{Button(onClick={vm.import(url)},enabled=url.isNotBlank()){Text("自动导入 / 更新")}}
        item{when(val x=state){ is ImportState.Success->Text("导入成功：${x.value.repository.fullName} · ${x.value.releaseCount} 个 Release"); is ImportState.Error->Text("导入失败：${x.message}"); ImportState.Loading->Text("正在读取 GitHub..."); else->Unit }}
        item{OutlinedTextField(query,{query=it},modifier=Modifier.fillMaxWidth(),label={Text("搜索项目")},singleLine=true)}
        items(results){r->ElevatedCard(onClick={onOpen(r.id)},modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(r.fullName,style=MaterialTheme.typography.titleMedium);Text(r.description.orEmpty(),maxLines=2);Text("⭐ ${r.stars}   ${r.language.orEmpty()}",style=MaterialTheme.typography.bodySmall)}}}
    }
}
