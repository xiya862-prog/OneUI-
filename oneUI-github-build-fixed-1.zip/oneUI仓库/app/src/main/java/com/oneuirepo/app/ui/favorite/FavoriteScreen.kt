package com.oneuirepo.app.ui.favorite

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.data.local.AppDatabase

@Composable fun FavoriteScreen(db:AppDatabase,onOpen:(Long)->Unit){
    val items by db.repositoryDao().observeFavorites().collectAsState(initial=emptyList())
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Text("收藏",style=MaterialTheme.typography.headlineMedium)}
        if(items.isEmpty())item{Text("还没有收藏项目")}
        items(items){r->ElevatedCard(onClick={onOpen(r.id)},modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(r.fullName,style=MaterialTheme.typography.titleMedium);Text(r.description.orEmpty(),maxLines=2);Text("⭐ ${r.stars}",style=MaterialTheme.typography.bodySmall)}}}
    }
}
