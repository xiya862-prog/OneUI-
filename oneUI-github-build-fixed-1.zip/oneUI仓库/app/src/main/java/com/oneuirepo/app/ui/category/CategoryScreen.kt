package com.oneuirepo.app.ui.category

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private val categories=listOf("One UI 9","One UI 8.5","One UI 8.0","SystemUI","RRO","主题","字体","模块","LSPosed","Shizuku","Root","KernelSU","Magisk","DeX","折叠屏","Watch","CVE")

@Composable fun CategoryScreen(){
    LazyVerticalGrid(GridCells.Fixed(2),Modifier.fillMaxSize().padding(16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
        item(span={GridItemSpan(maxLineSpan)}){Text("分类",style=MaterialTheme.typography.headlineMedium)}
        items(categories){ ElevatedCard{Text(it,Modifier.padding(18.dp))} }
    }
}
