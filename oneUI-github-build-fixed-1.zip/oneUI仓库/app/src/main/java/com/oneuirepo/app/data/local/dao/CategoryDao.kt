package com.oneuirepo.app.data.local.dao
import androidx.room.*
import com.oneuirepo.app.data.local.entity.*
@Dao interface CategoryDao { @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun upsertAll(x:List<CategoryEntity>); @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun addLinks(x:List<RepositoryCategoryCrossRef>); @Query("DELETE FROM repository_category_cross_ref WHERE repositoryId=:id") suspend fun deleteLinks(id:Long) }
