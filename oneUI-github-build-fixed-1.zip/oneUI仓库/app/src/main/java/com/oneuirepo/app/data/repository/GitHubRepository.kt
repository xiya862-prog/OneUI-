package com.oneuirepo.app.data.repository

import android.util.Base64
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.data.local.entity.*
import com.oneuirepo.app.data.remote.*
import com.oneuirepo.app.domain.classifier.ClassificationEngine
import com.oneuirepo.app.domain.model.ImportResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class GitHubRepository(
    private val api: GitHubApi,
    private val db: AppDatabase,
    private val c: ClassificationEngine
) {
    suspend fun import(owner: String, repo: String): ImportResult = withContext(Dispatchers.IO) {
        importDto(api.getRepository(owner, repo))
    }

    suspend fun syncExisting(repositoryId: Long): SyncOutcome = withContext(Dispatchers.IO) {
        val local = db.repositoryDao().findById(repositoryId) ?: return@withContext SyncOutcome(false, null)
        val parts = local.fullName.split('/', limit = 2)
        if (parts.size != 2) return@withContext SyncOutcome(false, null)
        val state = db.syncStateDao().find(repositoryId)
        val response = api.getRepositoryResponse(parts[0], parts[1], state?.etag)
        if (response.code() == 304) {
            db.syncStateDao().upsert(SyncStateEntity(repositoryId, state?.etag, System.currentTimeMillis()))
            return@withContext SyncOutcome(false, null)
        }
        val dto = response.body() ?: return@withContext SyncOutcome(false, null)
        val oldLatest = db.releaseDao().findLatest(repositoryId)?.tagName
        val result = importDto(dto)
        db.syncStateDao().upsert(SyncStateEntity(repositoryId, response.headers()["ETag"], System.currentTimeMillis()))
        val newLatest = db.releaseDao().findLatest(repositoryId)?.tagName
        SyncOutcome(oldLatest != null && newLatest != null && oldLatest != newLatest, newLatest)
    }

    private suspend fun importDto(r: GitHubRepositoryDto): ImportResult {
        val topics = runCatching { api.getTopics(r.owner.login, r.name).names }.getOrDefault(r.topics)
        val readme = runCatching { api.getReadme(r.owner.login, r.name) }.getOrNull()?.let { decode(it) }
        val releases = runCatching { api.getReleases(r.owner.login, r.name) }.getOrDefault(emptyList())
        val text = listOf(r.name, r.description.orEmpty(), topics.joinToString(" "), readme.orEmpty(), releases.joinToString(" ") { it.name.orEmpty() }).joinToString(" ")
        val cats = c.classify(text)
        val e = RepositoryEntity(
            r.id, r.owner.login, r.name, r.fullName, r.description, r.htmlUrl, r.owner.avatarUrl, null,
            r.stars, r.forks, r.watchers, r.language, r.license?.name ?: r.license?.key,
            topics.joinToString("\n"), readme,
            cats.filter { it.startsWith("One UI") }.joinToString("\n"),
            c.androidVersions(text).joinToString("\n"), c.devices(text).joinToString("\n"), c.requirements(readme),
            r.createdAt, r.updatedAt, System.currentTimeMillis(), r.archived, r.visibility
        )
        db.repositoryDao().upsert(e)
        db.categoryDao().upsertAll(c.allCategories.map { CategoryEntity(it, it) })
        db.categoryDao().deleteLinks(r.id)
        db.categoryDao().addLinks(cats.map { RepositoryCategoryCrossRef(r.id, it) })
        db.releaseDao().deleteAssets(r.id)
        db.releaseDao().deleteReleases(r.id)
        db.releaseDao().upsertAll(releases.map { rel -> ReleaseEntity(rel.id, r.id, rel.tagName, rel.name, rel.body, rel.publishedAt, rel.htmlUrl) })
        db.releaseDao().upsertAssets(releases.flatMap { rel -> rel.assets.map { a ->
            val n = a.name.lowercase()
            ReleaseAssetEntity(a.id, rel.id, a.name, a.size, a.browserDownloadUrl, a.contentType, a.downloadCount, a.digest,
                when { n.endsWith(".apk") -> "APK"; n.endsWith(".zip") -> "ZIP"; n.endsWith(".jar") -> "JAR"; else -> "OTHER" })
        } })
        val cveIds = Regex("CVE-\\d{4}-\\d{4,7}", RegexOption.IGNORE_CASE).findAll(text).map { it.value.uppercase() }.distinct().toList()
        if (cveIds.isNotEmpty()) db.cveDao().existingIds(cveIds).forEach { db.cveDao().link(com.oneuirepo.app.cve.RepositoryCveCrossRef(r.id, it)) }
        return ImportResult(e, cats.toList(), releases.size)
    }

    private fun decode(x: GitHubReadmeDto): String? = x.content?.let {
        if (x.encoding.equals("base64", true)) runCatching {
            Base64.decode(it.replace("\n", ""), Base64.DEFAULT).toString(Charsets.UTF_8)
        }.getOrNull() else it
    }
}

data class SyncOutcome(val changed: Boolean, val latestReleaseTag: String?)
