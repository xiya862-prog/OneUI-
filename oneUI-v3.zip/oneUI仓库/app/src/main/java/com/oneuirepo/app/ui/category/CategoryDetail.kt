package com.oneuirepo.app.ui.category

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.oneuirepo.app.data.local.AppDatabase
import com.oneuirepo.app.ui.common.EmptyHint
import com.oneuirepo.app.ui.common.RepoCard
import com.oneuirepo.app.ui.cve.CveScreen

@Composable
internal fun CategoryDetail(db: AppDatabase, name: String, onBack: () -> Unit, onOpen: (Long) -> Unit) {
    val cat = categories.firstOrNull { it.name == name }
    val isCve = name == "CVE"
    var cveTab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("← 返回") }
            Text("${cat?.emoji.orEmpty()} $name", style = MaterialTheme.typography.titleLarge)
        }
        if (isCve) {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = cveTab == 0, onClick = { cveTab = 0 }, label = { Text("漏洞列表") })
                FilterChip(selected = cveTab == 1, onClick = { cveTab = 1 }, label = { Text("相关项目") })
            }
            if (cveTab == 0) CveScreen(db) else RepoList(db, name, onOpen)
        } else {
            RepoList(db, name, onOpen)
        }
    }
}

@Composable
private fun RepoList(db: AppDatabase, name: String, onOpen: (Long) -> Unit) {
    val repos by db.categoryDao().observeRepos(name).collectAsState(initial = emptyList())
    var q by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(0) }
    val shown = remember(repos, q, sort) {
        val f = repos.filter { q.isBlank() || it.fullName.contains(q, true) || it.description.orEmpty().contains(q, true) }
        when (sort) {
            0 -> f.sortedByDescending { it.stars }
            1 -> f.sortedByDescending { it.updatedAt.orEmpty() }
            else -> f.sortedByDescending { it.createdAt.orEmpty() }
        }
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            OutlinedTextField(
                q, { q = it }, Modifier.fillMaxWidth(),
                label = { Text("在「$name」中搜索") }, singleLine = true
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = sort == 0, onClick = { sort = 0 }, label = { Text("⭐ Star") })
                FilterChip(selected = sort == 1, onClick = { sort = 1 }, label = { Text("🔄 最近更新") })
                FilterChip(selected = sort == 2, onClick = { sort = 2 }, label = { Text("🆕 最新") })
            }
        }
        item { Text("共 ${shown.size} 个项目", style = MaterialTheme.typography.bodySmall) }
        if (shown.isEmpty()) {
            item { EmptyHint("暂无项目，请到 GitHub 页导入仓库后自动归类") }
        }
        items(shown, key = { it.id }) { r -> RepoCard(r) { onOpen(r.id) } }
    }
}
