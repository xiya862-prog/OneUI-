package com.oneuirepo.app.ui.detail

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.*
import kotlinx.coroutines.launch
import androidx.lifecycle.viewmodel.compose.viewModel
import coil3.compose.AsyncImage
import com.oneuirepo.app.data.local.dao.*
import com.oneuirepo.app.data.local.entity.*
import com.oneuirepo.app.download.AppDownloadManager

class RepositoryDetailViewModel(private val db:com.oneuirepo.app.data.local.AppDatabase, private val id:Long):ViewModel(){
    val repository=db.repositoryDao().observeById(id)
    val releases=db.releaseDao().observeReleases(id)
    val assets=db.releaseDao().observeAssets(id)
    val favorite=db.favoriteDao().observeIsFavorite(id)
    fun toggleFavorite(current:Boolean)=viewModelScope.launch{if(current)db.favoriteDao().remove(id) else db.favoriteDao().add(FavoriteEntity(id,System.currentTimeMillis()))}
}
class RepositoryDetailFactory(private val db:com.oneuirepo.app.data.local.AppDatabase,private val id:Long):ViewModelProvider.Factory{
    @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T=RepositoryDetailViewModel(db,id) as T
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun RepositoryDetailScreen(id:Long,db:com.oneuirepo.app.data.local.AppDatabase,onBack:()->Unit){
    androidx.activity.compose.BackHandler(onBack=onBack)
    val vm:RepositoryDetailViewModel=viewModel(key="detail_$id",factory=RepositoryDetailFactory(db,id))
    val r by vm.repository.collectAsState(initial=null); val releases by vm.releases.collectAsState(initial=emptyList()); val assets by vm.assets.collectAsState(initial=emptyList()); val favorite by vm.favorite.collectAsState(initial=false)
    val cats by db.categoryDao().observeForRepo(id).collectAsState(initial=emptyList<String>()); val context=LocalContext.current; val downloader=remember{AppDownloadManager(context)}
    Scaffold(topBar={TopAppBar(title={Text(r?.name ?: "项目详情")},navigationIcon={TextButton(onClick=onBack){Text("返回")}})}){p->
        LazyColumn(Modifier.fillMaxSize().padding(p).padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
            item{r?.let{x->Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
                x.avatarUrl?.let{AsyncImage(model=it,contentDescription=null,modifier=Modifier.size(72.dp))}
                Text(x.fullName,style=MaterialTheme.typography.headlineSmall); Text(x.description.orEmpty());
                Text("⭐ ${x.stars}   Fork ${x.forks}   ${x.language.orEmpty()}",style=MaterialTheme.typography.bodyMedium)
                Text("分类：${cats.joinToString("、").ifBlank{"未分类"}}"); Text("标签：${x.topics.replace("\n", "、").ifBlank{"无"}}"); Text("One UI：${x.oneUiVersions.ifBlank{"未识别"}}"); Text("Android：${x.androidVersions.ifBlank{"未识别"}}"); Text("设备：${x.deviceCompatibility.ifBlank{"未识别"}}"); Text("环境要求：${x.requirements.ifBlank{"未识别"}}")
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={vm.toggleFavorite(favorite)}){Text(if(favorite)"取消收藏" else "收藏")}
                OutlinedButton(onClick={context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,android.net.Uri.parse(x.htmlUrl)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))}){Text("GitHub")}
                OutlinedButton(onClick={val i=android.content.Intent(android.content.Intent.ACTION_SEND).apply{type="text/plain";putExtra(android.content.Intent.EXTRA_TEXT,x.htmlUrl)};context.startActivity(android.content.Intent.createChooser(i,null).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))}){Text("分享")}
                }
            }}}
            item{Text("README",style=MaterialTheme.typography.titleLarge)}
            item{Text(r?.readme?.take(12000).orEmpty().ifBlank{"暂无 README"})}
            item{Text("Releases",style=MaterialTheme.typography.titleLarge)}
            items(releases){rel->Column(Modifier.fillMaxWidth()){Text("${rel.tagName} ${rel.name.orEmpty()}",style=MaterialTheme.typography.titleMedium);Text(rel.body.orEmpty().take(800),maxLines=8);assets.filter{it.releaseId==rel.id}.forEach{a->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${a.name} · ${a.fileType}",modifier=Modifier.weight(1f));TextButton(onClick={downloader.enqueue(a.downloadUrl,a.name)}){Text("下载")}}}}}
        }
    }
}
