package com.oneuirepo.app.data.local.dao

import androidx.room.*
import com.oneuirepo.app.data.local.entity.*
import kotlinx.coroutines.flow.Flow

data class CategoryCount(val categoryId: String, val cnt: Int)

@Dao
interface CategoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(x: List<CategoryEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addLinks(x: List<RepositoryCategoryCrossRef>)

    @Query("DELETE FROM repository_category_cross_ref WHERE repositoryId=:id")
    suspend fun deleteLinks(id: Long)

    @Query("SELECT categoryId AS categoryId, COUNT(*) AS cnt FROM repository_category_cross_ref GROUP BY categoryId")
    fun observeCounts(): Flow<List<CategoryCount>>

    @Query("SELECT r.* FROM repositories r INNER JOIN repository_category_cross_ref x ON r.id=x.repositoryId WHERE x.categoryId=:categoryId ORDER BY r.stars DESC")
    fun observeRepos(categoryId: String): Flow<List<RepositoryEntity>>

    @Query("SELECT categoryId FROM repository_category_cross_ref WHERE repositoryId=:repoId")
    fun observeForRepo(repoId: Long): Flow<List<String>>
}
