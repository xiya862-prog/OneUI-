package com.oneuirepo.app.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.*
import com.oneuirepo.app.data.local.dao.RepositoryDao
import com.oneuirepo.app.ui.common.EmptyHint
import com.oneuirepo.app.ui.common.RepoCard

class HomeViewModel(dao: RepositoryDao) : ViewModel() {
    val popular = dao.observePopular()
    val newest = dao.observeNewest()
    val updated = dao.observeRecentlyUpdated()
}

class HomeVMFactory(private val d: RepositoryDao) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = HomeViewModel(d) as T
}

@Composable
fun HomeScreen(vm: HomeViewModel, onSearch: () -> Unit, onOpen: (Long) -> Unit) {
    val p by vm.popular.collectAsState(initial = emptyList())
    val n by vm.newest.collectAsState(initial = emptyList())
    val u by vm.updated.collectAsState(initial = emptyList())
    var mode by remember { mutableStateOf(0) }
    val titles = listOf("精选", "热门", "最新", "更新")
    val list = when (mode) {
        1 -> p.take(30)
        2 -> n.take(30)
        3 -> u.take(30)
        else -> (p.take(4) + n.take(3) + u.take(3)).distinctBy { it.id }
    }
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                onClick = onSearch,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(50),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(Modifier.padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🔍  搜索 GitHub 仓库", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                titles.forEachIndexed { i, t ->
                    val sel = mode == i
                    Column(
                        Modifier.clickable { mode = i }.padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            t,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                            color = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(4.dp))
                        Box(
                            Modifier.width(22.dp).height(3.dp).clip(RoundedCornerShape(2.dp))
                                .background(if (sel) MaterialTheme.colorScheme.primary else Color.Transparent)
                        )
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Banner("🔥 热门项目", Color(0xFF3D8FC4), Color(0xFF5E7BC4), Modifier.weight(1f)) { mode = 1 }
                Banner("🆕 最新项目", Color(0xFFE08B5A), Color(0xFFD9737F), Modifier.weight(1f)) { mode = 2 }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "推荐项目",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Text("共 ${list.size} 个", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (list.isEmpty()) {
            item { EmptyHint("还没有项目，去「GitHub」页粘贴仓库地址导入") }
        }
        items(list, key = { it.id }) { r -> RepoCard(r) { onOpen(r.id) } }
    }
}

@Composable
private fun Banner(text: String, c1: Color, c2: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(96.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.linearGradient(listOf(c1, c2)))
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
    }
}
