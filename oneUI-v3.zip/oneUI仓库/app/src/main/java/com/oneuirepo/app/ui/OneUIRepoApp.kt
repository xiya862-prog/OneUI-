package com.oneuirepo.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.ui.home.*
import com.oneuirepo.app.ui.github.*
import com.oneuirepo.app.ui.category.CategoryScreen
import com.oneuirepo.app.ui.favorite.FavoriteScreen
import com.oneuirepo.app.ui.settings.SettingsScreen
import com.oneuirepo.app.ui.detail.RepositoryDetailScreen

private enum class Tab(val title:String,val icon:String){HOME("首页","⌂"),CATEGORY("分类","▦"),GITHUB("GitHub","G"),FAVORITE("收藏","♡"),SETTINGS("设置","⚙")}

@Composable fun OneUIRepoApp(c:AppContainer){
    var tab by remember{mutableStateOf(Tab.HOME)}
    var category by remember{mutableStateOf<String?>(null)}
    var selectedRepoId by remember{mutableStateOf<Long?>(null)}
    if(selectedRepoId!=null){
        RepositoryDetailScreen(selectedRepoId!!,c.db){selectedRepoId=null}
        return
    }
    val h:HomeViewModel=viewModel(factory=HomeVMFactory(c.db.repositoryDao()))
    val g:GitHubViewModel=viewModel(factory=GitHubViewModelFactory(c))
    Scaffold(bottomBar={NavigationBar(containerColor=MaterialTheme.colorScheme.surface){Tab.entries.forEach{t->NavigationBarItem(selected=tab==t,onClick={tab=t},icon={Text(t.icon)},label={Text(t.title)})}}}){p->
        Box(Modifier.fillMaxSize().padding(p)){when(tab){
            Tab.HOME->HomeScreen(h,{tab=Tab.GITHUB}){selectedRepoId=it}
            Tab.CATEGORY->CategoryScreen(c.db,category,{category=it}){selectedRepoId=it}
            Tab.GITHUB->GitHubScreen(g,c){selectedRepoId=it}
            Tab.FAVORITE->FavoriteScreen(c.db){selectedRepoId=it}
            Tab.SETTINGS->SettingsScreen(c)
        }}
    }
}
