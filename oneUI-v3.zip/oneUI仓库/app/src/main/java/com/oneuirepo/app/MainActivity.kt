package com.oneuirepo.app

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.oneuirepo.app.data.repository.AppContainer
import com.oneuirepo.app.sync.SyncScheduler
import com.oneuirepo.app.cve.CveScheduler
import com.oneuirepo.app.ui.OneUIRepoApp

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        SyncScheduler.schedule(applicationContext)
        CveScheduler.schedule(applicationContext)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val c = AppContainer(applicationContext)
        setContent {
            val dark = androidx.compose.foundation.isSystemInDarkTheme()
            val scheme = if (dark) AppDark else AppLight
            MaterialTheme(colorScheme = scheme) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { OneUIRepoApp(c) }
            }
        }
    }
}

private val AppLight = lightColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFF3E9A55),
    onPrimary = androidx.compose.ui.graphics.Color.White,
    primaryContainer = androidx.compose.ui.graphics.Color(0xFFD7F0DD),
    onPrimaryContainer = androidx.compose.ui.graphics.Color(0xFF0B3D1A),
    secondaryContainer = androidx.compose.ui.graphics.Color(0xFFE6EEE8),
    onSecondaryContainer = androidx.compose.ui.graphics.Color(0xFF1B3A24),
    tertiary = androidx.compose.ui.graphics.Color(0xFF3D8FC4),
    background = androidx.compose.ui.graphics.Color(0xFFF1F1F6),
    surface = androidx.compose.ui.graphics.Color.White,
    onSurface = androidx.compose.ui.graphics.Color(0xFF1A1A1A),
    surfaceVariant = androidx.compose.ui.graphics.Color(0xFFE9E9EF),
    onSurfaceVariant = androidx.compose.ui.graphics.Color(0xFF6B6B73)
)

private val AppDark = darkColorScheme(
    primary = androidx.compose.ui.graphics.Color(0xFF6BCB84),
    onPrimary = androidx.compose.ui.graphics.Color(0xFF00210C),
    primaryContainer = androidx.compose.ui.graphics.Color(0xFF1F4D2E),
    onPrimaryContainer = androidx.compose.ui.graphics.Color(0xFFD7F0DD),
    secondaryContainer = androidx.compose.ui.graphics.Color(0xFF26332A),
    onSecondaryContainer = androidx.compose.ui.graphics.Color(0xFFDDE8DF),
    tertiary = androidx.compose.ui.graphics.Color(0xFF7CC4F0),
    background = androidx.compose.ui.graphics.Color.Black,
    surface = androidx.compose.ui.graphics.Color(0xFF151517),
    onSurface = androidx.compose.ui.graphics.Color(0xFFEDEDED),
    surfaceVariant = androidx.compose.ui.graphics.Color(0xFF232326),
    onSurfaceVariant = androidx.compose.ui.graphics.Color(0xFFA0A0A8)
)
